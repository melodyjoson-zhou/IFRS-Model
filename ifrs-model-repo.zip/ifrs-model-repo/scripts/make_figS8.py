#!/usr/bin/env python3
"""figS8: neutrophil extracellular trap extension — dynamics, stratification,
deficiency dose-response, LHS correlations."""
import sys
sys.path.insert(0, '/mnt/results/ifrs_model')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import fungal_sinusitis_ode_model as fsm
import fungal_sinusitis_nets as fnt

matplotlib.rcParams['font.family'] = ['Liberation Sans', 'Arimo', 'DejaVu Sans']
matplotlib.rcParams['svg.fonttype'] = 'none'

C_BLUE, C_ORANGE, C_GREEN, C_RED = '#0279EE', '#FF9400', '#75A025', '#C44E52'
C_MUTED = '#8A8378'
FIG = '/mnt/results/ifrs_model/figures'

t_eval = np.linspace(0, 168, 841)
NEU = {'N_base': 0.05, 'k_N_rec_mult': 0.1}
iH, iTn, iNa = fnt._I_H, fnt._N19, fnt._I_Na

# --- panel a: Tn trajectories, three hosts ---
traj = {}
for name, kw in [('immunocompetent', {}), ('iron_x2', {'params_override': {'k_Fe_in': 1.0}}),
                 ('neutropenic', {'neutropenia': NEU})]:
    traj[name] = fnt.solve_model_nets(t_eval=t_eval, **kw)

# --- panel b: H trajectories NET model vs core (immunocompetent + iron_x2) ---
core_ic = fsm.solve_model(t_eval=t_eval)
core_x2 = fsm.solve_model(t_eval=t_eval, params_override={'k_Fe_in': 1.0})

# --- panel c: NET-deficiency dose response (H_auc) ---
mults = [0.0, 0.25, 0.5, 1.0, 2.0]
dose = {}
for host, kw in [('immunocompetent', {}), ('iron_x2', {'params_override': {'k_Fe_in': 1.0}})]:
    row = []
    for m in mults:
        ov = {'k_net_form': fnt.DEFAULT_PARAMS_NETS['k_net_form'] * m}
        kwc = dict(kw)
        kwc['params_override'] = {**kw.get('params_override', {}), **ov}
        r = fnt.solve_model_nets(t_eval=t_eval, **kwc)
        row.append(float(np.trapezoid(r.y[iH], r.t)))
    dose[host] = row

# --- panel d: LHS correlations ---
corr = pd.read_csv('/workspace/ifrs_nets_lhs_correlations.csv', index_col=0).iloc[:, 0]
keys = ['k_net_form', 'K_net_stim', 'k_net_kill', 'k_net_kill_s', 'k_net_loss',
        'k_Nkill', 'K_kill', 'mu_H', 'k_Fe_in', 'k_up', 'k_gtx_prod']

fig, axes = plt.subplots(2, 2, figsize=(11, 8.2))
ax = axes[0, 0]
cols = {'immunocompetent': C_GREEN, 'iron_x2': C_ORANGE, 'neutropenic': C_RED}
for name, r in traj.items():
    ax.plot(r.t, r.y[iTn], color=cols[name], lw=2, label=name)
ax.set_xlabel('Time (h)'); ax.set_ylabel('NET burden Tn (AU)')
ax.set_title('a  NET dynamics by host (Tn)', loc='left', fontsize=11)
ax.legend(fontsize=8, frameon=False)

ax = axes[0, 1]
ax.plot(traj['immunocompetent'].t, traj['immunocompetent'].y[iH], color=C_GREEN, lw=2, label='immunocompetent (NET)')
ax.plot(traj['iron_x2'].t, traj['iron_x2'].y[iH], color=C_ORANGE, lw=2, label='iron x2 (NET)')
ax.plot(traj['neutropenic'].t, traj['neutropenic'].y[iH], color=C_RED, lw=2, label='neutropenic (NET)')
ax.plot(core_ic.t, core_ic.y[iH], color=C_GREEN, lw=1.2, ls='--', alpha=0.6, label='core (dashed)')
ax.plot(core_x2.t, core_x2.y[iH], color=C_ORANGE, lw=1.2, ls='--', alpha=0.6)
ax.plot(fsm.solve_model(t_eval=t_eval, neutropenia=NEU).t,
        fsm.solve_model(t_eval=t_eval, neutropenia=NEU).y[iH], color=C_RED, lw=1.2, ls='--', alpha=0.6)
ax.axhline(1.0, color='k', lw=0.8, ls=':')
ax.set_yscale('symlog', linthresh=0.1); ax.set_ylim(0.008, 30)
ax.set_xlabel('Time (h)'); ax.set_ylabel('Hyphal burden H (AU)')
ax.set_title('b  Host stratification, NET model vs core', loc='left', fontsize=11)
ax.legend(fontsize=7, frameon=False)

ax = axes[1, 0]
for host, color in [('immunocompetent', C_GREEN), ('iron_x2', C_ORANGE)]:
    ax.plot(mults, dose[host], 'o-', color=color, lw=2, ms=5, label=host)
ax.axhline(2388, color=C_ORANGE, lw=1, ls='--', alpha=0.6)
ax.axhline(155, color=C_GREEN, lw=1, ls='--', alpha=0.6)
ax.set_xscale('log'); ax.set_yscale('log')
ax.set_xlabel('NETosis rate multiplier (k_net_form x)')
ax.set_ylabel('Burden-time area H_auc (AU·h)')
ax.set_title('c  NET-deficiency dose response', loc='left', fontsize=11)
ax.legend(fontsize=8, frameon=False)

ax = axes[1, 1]
x = np.arange(len(keys))
vals = [corr.get(k, np.nan) for k in keys]
ax.bar(x, vals, color=[C_BLUE if k.startswith('k_net') or k == 'K_net_stim' else C_MUTED for k in keys])
ax.axhline(0, color='k', lw=0.8)
ax.set_xticks(x); ax.set_xticklabels(keys, rotation=45, ha='right', fontsize=8)
ax.set_ylabel('Pearson r with H_end')
ax.set_title('d  LHS correlations (25,000 runs)', loc='left', fontsize=11)

fig.tight_layout()
for ext in ('png', 'svg', 'tiff'):
    fig.savefig(f'{FIG}/figS8_nets.{ext}', dpi=300, bbox_inches='tight')
print('figS8 saved:', [f'figS8_nets.{e}' for e in ('png', 'svg', 'tiff')])
print('NET-param correlations:', {k: round(float(corr.get(k, np.nan)), 3)
                                   for k in ['k_net_form', 'k_net_kill', 'k_net_kill_s', 'k_net_loss']})
