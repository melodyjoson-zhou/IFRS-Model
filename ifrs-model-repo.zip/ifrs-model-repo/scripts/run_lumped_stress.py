"""run_lumped_stress.py — f-grid stress test of the alpha/beta uniformity
assumption: escape thresholds, three-host stratification, intervention window.
Outputs /workspace/ifrs_lumped_stress_test.csv (long format).
"""
import numpy as np
import pandas as pd

from lumped_stress import (solve_model_gen, skew_lumped_gen,
                           outcome_metrics_gen, simulate_treatment_gen,
                           default_lumped_gen)

F_GRID = [0.25, 0.5, 1.0, 2.0, 4.0]
H_THRESH = 1.0
TIMINGS = [0.0, 24.0, 48.0, 72.0, 96.0, 120.0]
rows = []


def add_row(modifier, f, test, item, value):
    rows.append({'modifier': modifier, 'f': f, 'test': test,
                 'item': item, 'value': value})


def h_end(lumped_gen, **kw):
    r = solve_model_gen(lumped_gen=lumped_gen, **kw)
    return r.y[fsm_H][-1]


import fungal_sinusitis_ode_model as fsm
fsm_H = fsm.STATE_NAMES.index('H')


def bisect_threshold(modifier, base, f, lo, hi, increasing, n_iter=60):
    """Find base-value where H_end crosses 1 AU under skew(modifier, base, f)."""
    def esc(b):
        return h_end(skew_lumped_gen(modifier, b, f)) > H_THRESH
    if increasing:          # escape as base increases (beta)
        if not esc(hi):
            return np.nan
        if esc(lo):
            return lo
    else:                   # escape as base decreases (alpha)
        if not esc(lo):
            return np.nan
        if esc(hi):
            return hi
    for _ in range(n_iter):
        mid = 0.5 * (lo + hi)
        if esc(mid):
            if increasing:
                hi = mid
            else:
                lo = mid
        else:
            if increasing:
                lo = mid
            else:
                hi = mid
        if hi - lo < 1e-3:
            break
    return 0.5 * (lo + hi)


# --- Test A: escape thresholds -------------------------------------------
thr_ref = {}
for modifier, base in (('beta', 1.0), ('alpha', 1.0)):
    for f in F_GRID:
        if modifier == 'beta':
            thr = bisect_threshold('beta', base, f, 0.5, 8.0, increasing=True)
        else:
            thr = bisect_threshold('alpha', base, f, 0.05, 2.0, increasing=False)
        add_row(modifier, f, 'threshold',
                'beta_escape' if modifier == 'beta' else 'alpha_escape', thr)
        thr_ref[(modifier, f)] = thr

# --- Test B: three-host stratification ------------------------------------
HOSTS = {
    'immunocompetent': {},
    'iron_x2': {'params_override': {'k_Fe_in': 1.0}},
    'neutropenic': {'neutropenia': {'N_base': 0.05, 'k_N_rec_mult': 0.1}},
}
for modifier in ('beta', 'alpha'):
    for f in F_GRID:
        for host, kw in HOSTS.items():
            m = outcome_metrics_gen(solve_model_gen(
                lumped_gen=skew_lumped_gen(modifier, 1.0, f), **kw))
            for k, v in m.items():
                add_row(modifier, f, 'scenario', f'{host}:{k}', v)

# --- Test C: intervention window (90% antifungal, neutropenic host) -------
for modifier in ('beta', 'alpha'):
    for f in F_GRID:
        L = skew_lumped_gen(modifier, 1.0, f)
        clears = []
        for tau in TIMINGS:
            t, Y = simulate_treatment_gen(L, t_start=tau, eff=0.9, neutropenic=True)
            He = Y[:, fsm_H][-1]
            add_row(modifier, f, 'window', f'90pct@+{int(tau)}h:H_end', He)
            if He < H_THRESH:
                clears.append(tau)
        add_row(modifier, f, 'window', 'max_clearing_tau_h',
                max(clears) if clears else np.nan)

df = pd.DataFrame(rows)
df.to_csv('/workspace/ifrs_lumped_stress_test.csv', index=False)

# --- console summary -------------------------------------------------------
print('=== Escape thresholds (H_end = 1 AU) ===')
for modifier in ('beta', 'alpha'):
    ref = thr_ref[(modifier, 1.0)]
    for f in F_GRID:
        thr = thr_ref[(modifier, f)]
        print(f"{modifier:>5} f={f:4}: threshold = {thr:.3f} "
              f"(ratio vs f=1: {thr / ref:.3f})")

print('\n=== Three-host H_auc ordering (must be ic < iron_x2 << neutropenic) ===')
for modifier in ('beta', 'alpha'):
    for f in F_GRID:
        vals = {h: df[(df.modifier == modifier) & (df.f == f) &
                      (df.item == f'{h}:H_auc')]['value'].iloc[0]
                for h in HOSTS}
        ok = (vals['immunocompetent'] < vals['iron_x2'] < vals['neutropenic'])
        print(f"{modifier:>5} f={f:4}: ic={vals['immunocompetent']:8.1f}  "
              f"iron2={vals['iron_x2']:8.1f}  neutropenic={vals['neutropenic']:8.1f}  "
              f"ordered={ok}")

print('\n=== Intervention window (90% efficacy, neutropenic host) ===')
for modifier in ('beta', 'alpha'):
    for f in F_GRID:
        v = df[(df.modifier == modifier) & (df.f == f) &
               (df.item == 'max_clearing_tau_h')]['value'].iloc[0]
        print(f"{modifier:>5} f={f:4}: max clearing tau = {v} h")
