#!/usr/bin/env python3
"""figS9: non-uniformity stress test of the aggregate modifiers alpha/beta —
escape thresholds, three-host stratification, intervention window vs skew f."""
import sys
sys.path.insert(0, '/mnt/results/ifrs_model')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

matplotlib.rcParams['font.family'] = ['Liberation Sans', 'Arimo', 'DejaVu Sans']
matplotlib.rcParams['svg.fonttype'] = 'none'

C_BLUE, C_ORANGE, C_GREEN, C_RED = '#0279EE', '#FF9400', '#75A025', '#C44E52'
C_MUTED = '#8A8378'
FIG = '/mnt/results/ifrs_model/figures'

df = pd.read_csv('/workspace/ifrs_lumped_stress_test.csv')
F_GRID = [0.25, 0.5, 1.0, 2.0, 4.0]

def get(modifier, f, test, item):
    m = (df.modifier == modifier) & (df.f == f) & (df.test == test) & (df.item == item)
    return float(df[m]['value'].iloc[0])

fig, axes = plt.subplots(1, 3, figsize=(13.5, 4.2))

# --- panel a: escape thresholds vs skew f ---
ax = axes[0]
fs = np.array(F_GRID)
beta_thr = np.array([get('beta', f, 'threshold', 'beta_escape') for f in F_GRID])
alpha_thr = np.array([get('alpha', f, 'threshold', 'alpha_escape') for f in F_GRID])
ax.plot(fs, beta_thr, 'o-', color=C_BLUE, lw=2, label='beta escape threshold (right)')
ax.plot(fs, alpha_thr, 's--', color=C_GREEN, lw=2, label='alpha escape threshold (left)')
ax.set_xscale('log')
ax.axvline(1.0, color=C_MUTED, lw=1, ls=':')
ax.axhline(1.0, color=C_MUTED, lw=1, ls=':')
ax.set_xlabel('Skew factor f (log)')
ax.set_ylabel('alpha escape threshold (beta = 1)')
ax.set_ylim(0, 1.45)
ax2 = ax.twinx()
ax2.plot(fs, beta_thr, 'o-', color=C_BLUE, lw=2)
ax2.set_ylabel('beta escape threshold (alpha = 1)', color=C_BLUE)
ax2.tick_params(axis='y', colors=C_BLUE)
ax2.set_ylim(0, 7.6)
ax.set_title('a  Escape thresholds vs rebalancing', loc='left', fontsize=11)
ax.legend(fontsize=8, frameon=False, loc='upper left')

# --- panel b: three-host H_auc vs skew f ---
ax = axes[1]
hosts = [('immunocompetent', C_GREEN, 'o'), ('iron_x2', C_ORANGE, 's'),
         ('neutropenic', C_RED, '^')]
for host, color, mk in hosts:
    yb = [get('beta', f, 'scenario', f'{host}:H_auc') for f in F_GRID]
    ya = [get('alpha', f, 'scenario', f'{host}:H_auc') for f in F_GRID]
    ax.plot(fs, yb, '-', marker=mk, color=color, lw=2,
            label=f'{host} (beta skew)')
    ax.plot(fs, ya, '--', marker=mk, mfc='white', color=color, lw=1.6,
            label=f'{host} (alpha skew)')
ax.axvspan(2.0, 4.0, color=C_MUTED, alpha=0.12)
ax.text(2.55, 30, 'wild-type fungus\npast frontier', fontsize=8,
        color=C_MUTED, ha='center')
ax.set_xscale('log'); ax.set_yscale('log')
ax.set_xlabel('Skew factor f (log)')
ax.set_ylabel('Burden-time area H_auc (AU·h)')
ax.set_title('b  Three-host exposure vs rebalancing', loc='left', fontsize=11)
ax.legend(fontsize=6.5, frameon=False, ncol=1, loc='upper left')

# --- panel c: intervention window vs skew f ---
ax = axes[2]
NEVER = -6.0
for modifier, color, mk, ls in (('beta', C_BLUE, 'o', '-'), ('alpha', C_ORANGE, 's', '--')):
    tau = [get(modifier, f, 'window', 'max_clearing_tau_h') for f in F_GRID]
    tau = [NEVER if np.isnan(v) else v for v in tau]
    ax.plot(fs, tau, ls, marker=mk, color=color, lw=2,
            label=f'{modifier} skew')
ax.set_xscale('log')
ax.set_yticks([NEVER, 0, 24, 48, 72, 96, 120])
ax.set_yticklabels(['never', '0', '24', '48', '72', '96', '120'])
ax.set_xlabel('Skew factor f (log)')
ax.set_ylabel('Max clearing onset tau (h)')
ax.set_title('c  90%-efficacy window vs rebalancing', loc='left', fontsize=11)
ax.legend(fontsize=8, frameon=False)

fig.tight_layout()
out = []
for ext in ('png', 'svg', 'tiff'):
    p = f'{FIG}/figS9_lumped_stress.{ext}'
    fig.savefig(p, dpi=300 if ext != 'svg' else None)
    out.append(p.split('/')[-1])
print('figS9 saved:', out)
