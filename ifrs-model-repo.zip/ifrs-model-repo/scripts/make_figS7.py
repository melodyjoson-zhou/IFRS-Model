#!/usr/bin/env python3
"""figS7: compartmental iron dynamics — artifact fix and host stratification."""
import sys
sys.path.insert(0, '/mnt/results/ifrs_model')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import fungal_sinusitis_ode_model as fsm
import fungal_sinusitis_iron as fir

matplotlib.rcParams['font.family'] = ['Liberation Sans', 'Arimo', 'DejaVu Sans']
matplotlib.rcParams['svg.fonttype'] = 'none'

C_BLUE, C_ORANGE, C_GREEN, C_RED = '#0279EE', '#FF9400', '#75A025', '#C44E52'
C_MUTED = '#8A8378'
FIG = '/mnt/results/ifrs_model/figures'

t_eval = np.linspace(0, 168, 841)
NEU = {'N_base': 0.05, 'k_N_rec_mult': 0.1}

# --- data: trajectories ---
r3 = fir.solve_model_iron(neutropenia=NEU, t_eval=t_eval)
r1 = fsm.solve_model(neutropenia=NEU, t_eval=t_eval)
Y3, Y1 = r3.y, r1.y
iFe, iFeP, iFeF = (fsm.STATE_NAMES.index('Fe'), fir.STATE_NAMES_IRON_FULL.index('Fe_P'),
                   fir.STATE_NAMES_IRON_FULL.index('Fe_F'))
iH = fsm.STATE_NAMES.index('H')

# --- data: LHS correlations old vs new ---
old = pd.read_csv('/mnt/results/ifrs_model/ifrs_lhs_correlations.csv', index_col=0).iloc[:, 0]
new = pd.read_csv('/workspace/ifrs_iron_lhs_correlations.csv', index_col=0).iloc[:, 0]
runs = pd.read_csv('/workspace/ifrs_iron_lhs_runs.csv')
valid = runs.dropna(subset=['H_end'])

# --- data: host stratification (three-pool) ---
traj = {}
for name, kw in [('immunocompetent', {}), ('iron_x2', {'params_override': {'k_Fe_in': 1.0}}),
                 ('neutropenic', {'neutropenia': NEU})]:
    traj[name] = fir.solve_model_iron(t_eval=t_eval, **kw)

# --- data: sigma dependence of AF90 monotherapy ---
def piecewise_neu_af90(sigma):
    """AF90@24h in neutropenia: two-stage integration with state continuation."""
    ic = None
    Y = None
    t_all, y_all = [], []
    for t0, t1, kw in [(0, 24, {'neutropenia': NEU}),
                       (24, 168, {'neutropenia': NEU,
                                  'params_override': {'mu_H': 0.036, 'sigma_Fe': sigma}})]:
        te = np.linspace(t0, t1, int(t1 - t0) + 1)
        r = fir.solve_model_iron(t_span=(t0, t1), t_eval=te, ic=ic, **kw)
        t_all.append(r.t); y_all.append(r.y)
        ic = dict(zip(fir.STATE_NAMES_IRON_FULL, r.y[:, -1]))
        Y = r.y
    return np.concatenate(t_all), np.concatenate(y_all, axis=1)

sigmas = [0.5, 0.75, 1.0, 1.5, 2.0, 3.0]
hend = [piecewise_neu_af90(s)[1][iH, -1] for s in sigmas]

fig, axes = plt.subplots(2, 2, figsize=(11, 8.2))
ax = axes[0, 0]
ax.plot(r3.t, Y3[iFeP], color=C_BLUE, lw=2, label='Fe_P plasma (3-pool)')
ax.plot(r3.t, Y3[iFe], color=C_ORANGE, lw=2, label='Fe_T tissue (3-pool)')
ax.plot(r3.t, Y3[iFeF], color=C_GREEN, lw=2, label='Fe_F fungal (3-pool)')
ax.plot(r1.t, Y1[iFe], color=C_MUTED, lw=1.6, ls='--', label='Fe single-pool (delivered)')
ax.set_xlabel('Time (h)'); ax.set_ylabel('Iron (AU, 1 = normal)')
ax.set_title('a  Iron pools, untreated neutropenic escape', loc='left', fontsize=11)
ax.legend(fontsize=8, frameon=False); ax.set_ylim(bottom=0)

ax = axes[0, 1]
keys = ['k_up', 'k_Fe_in', 'mu_H', 'k_seq', 'K_Fe_H', 'K_kill', 'k_Nkill']
x = np.arange(len(keys)); w = 0.38
ax.bar(x - w/2, [old.get(k, np.nan) for k in keys], w, color=C_MUTED, label='single-pool (delivered)')
ax.bar(x + w/2, [new.get(k, np.nan) for k in keys], w, color=C_BLUE, label='compartmental (3-pool)')
ax.axhline(0, color='k', lw=0.8)
ax.set_xticks(x); ax.set_xticklabels(keys, rotation=45, ha='right', fontsize=9)
ax.set_ylabel('Pearson r with H_end')
ax.set_title('b  LHS correlation shift (25,000 runs each)', loc='left', fontsize=11)
ax.legend(fontsize=8, frameon=False)

ax = axes[1, 0]
cols = {'immunocompetent': C_GREEN, 'iron_x2': C_ORANGE, 'neutropenic': C_RED}
for name, r in traj.items():
    ax.plot(r.t, r.y[iH], color=cols[name], lw=2, label=name)
ax.axhline(1.0, color='k', lw=0.8, ls=':')
ax.set_yscale('symlog', linthresh=0.1)
ax.set_ylim(0.008, 30)
ax.set_xlabel('Time (h)'); ax.set_ylabel('Hyphal burden H (AU)')
ax.set_title('c  Host stratification (3-pool iron)', loc='left', fontsize=11)
ax.legend(fontsize=8, frameon=False)

ax = axes[1, 1]
ax.plot(sigmas, hend, 'o-', color=C_BLUE, lw=2, ms=5)
ax.axhline(1.0, color=C_RED, lw=1, ls='--')
ax.text(2.6, 1.6, 'clearance threshold (1 AU)', fontsize=8, color=C_RED)
ax.set_xlabel('Fungal iron cost per biomass (sigma_Fe)')
ax.set_ylabel('H_end under AF90%@24h (AU)')
ax.set_yscale('log')
ax.set_title('d  Monotherapy outcome vs fungal iron demand', loc='left', fontsize=11)

fig.tight_layout()
for ext in ('png', 'svg', 'tiff'):
    fig.savefig(f'{FIG}/figS7_iron_compartments.{ext}', dpi=300, bbox_inches='tight')
print('figS7 saved:', [f'figS7_iron_compartments.{e}' for e in ('png', 'svg', 'tiff')])
print('k_up correlation: single', round(float(old.get('k_up', np.nan)), 3),
      '-> compartmental', round(float(new.get('k_up', np.nan)), 3))
