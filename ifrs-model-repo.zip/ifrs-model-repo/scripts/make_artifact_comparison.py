#!/usr/bin/env python3
"""Build ifrs_iron_artifact_comparison.csv: per-parameter Pearson correlations
with H_end, single-pool (delivered) vs compartmental (3-pool) LHS."""
import os, shutil
import pandas as pd

MODEL_DIR = "/mnt/results/ifrs_model"
old = pd.read_csv(os.path.join(MODEL_DIR, "ifrs_lhs_correlations.csv"), index_col=0).iloc[:, 0]
new = pd.read_csv("/workspace/ifrs_iron_lhs_correlations.csv", index_col=0).iloc[:, 0]

cmp = pd.DataFrame({
    "parameter": new.index,
    "pearson_r_single_pool": [old.get(p, float("nan")) for p in new.index],
    "pearson_r_compartmental": new.values,
})
cmp["delta"] = cmp["pearson_r_compartmental"] - cmp["pearson_r_single_pool"]
cmp = cmp.sort_values("pearson_r_compartmental", key=lambda s: -s.abs())

stage = "/workspace/stage_csv/ifrs_iron_artifact_comparison.csv"
cmp.to_csv(stage, index=False, float_format="%.4f")

dst = os.path.join(MODEL_DIR, "ifrs_iron_artifact_comparison.csv")
if os.path.exists(dst):
    os.remove(dst)
shutil.copyfile(stage, dst)

key = cmp[cmp.parameter.isin(["k_up", "k_Fe_in", "mu_H", "k_seq", "K_Fe_H", "K_kill", "k_Nkill"])]
print(key.to_string(index=False))
print(f"\ninstalled {dst} ({len(cmp)} parameters)")
