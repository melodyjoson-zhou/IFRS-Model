#!/usr/bin/env python3
"""25,000-run LHS for the compartmental-iron IFRS model (delivered protocol)."""
import sys, time
sys.path.insert(0, '/mnt/results/ifrs_model')
import numpy as np
import pandas as pd
import fungal_sinusitis_iron as fir

t0 = time.time()
CKPT = '/workspace/iron_lhs_checkpoint.csv'
df, perturbed = fir.run_lhs_iron(n_runs=25000, seed=2026, iron_model='three',
                                 t_span=(0.0, 168.0), n_eval=169, checkpoint=CKPT)
df.to_csv('/workspace/ifrs_iron_lhs_runs.csv', index=False)
valid = df.dropna(subset=['H_end'])
print(f'LHS done in {time.time()-t0:.0f}s: {len(df)} runs, {len(valid)} valid '
      f'({100*(len(df)-len(valid))/len(df):.1f}% NaN)')

# Pearson correlations (delivered protocol)
corr = valid.corr(method='pearson')['H_end'].drop('H_end')
corr.sort_values().to_csv('/workspace/ifrs_iron_lhs_correlations.csv')
print('--- key correlations (vs H_end) ---')
for k in ['k_up', 'k_Fe_in', 'mu_H', 'k_seq', 'K_Fe_H', 'K_Fe_F', 'sigma_Fe',
          'k_PT', 'k_TP', 'k_Fe_P_loss', 'k_Fe_F_loss', 'K_kill', 'k_Nkill']:
    if k in corr.index:
        print(f'  {k:>12s}: {corr[k]:+.3f}')
print('done')
