"""Unit tests + qualitative validation targets for the vascular module."""
import sys
sys.path.insert(0, '/mnt/results/ifrs_model')
import numpy as np
import fungal_sinusitis_2comp as f2c
import fungal_sinusitis_vascular as fv

ok = True

# --- T1: plumbing -- with k_nec = 0 (Nec identically 0), tissue trajectory
#     must match the 25-state two-compartment model exactly
p0 = {'k_nec': 0.0}
te = np.linspace(0, 168, 421)
r25 = f2c.solve_model_2c(t_span=(0, 168), t_eval=te)
r28 = fv.solve_model_vasc(t_span=(0, 168), t_eval=te, params_override=p0)
diff = np.abs(r28.y[:25] - r25.y).max()
print(f'T1 plumbing (k_nec=0 -> tissue identical to 2-comp): max|diff| = {diff:.2e}')
ok &= diff < 1e-6

# --- T2: bounds E, Th, Nec in [0,1] across host backgrounds and 504 h
hosts = {
    'immunocompetent': {},
    'neutropenic': {'N_base': 0.05, 'k_N_rec_mult': 0.1},
    'iron_x2': {'k_Fe_in_mult': 2.0},
}
for nm, ov in hosts.items():
    if 'k_Fe_in_mult' in ov:
        ov = {'k_Fe_in': f2c.DEFAULT_PARAMS_2C['k_Fe_in'] * 2.0}
    rb = fv.solve_model_vasc_bone(t_span=(0, 504), params_override=ov)
    for s in ('E', 'Th', 'Nec'):
        v = rb.y[fv.STATE_NAMES_VASC.index(s)]
        good = v.min() >= -1e-9 and v.max() <= 1 + 1e-9
        ok &= good
        print(f'T2 bounds {nm:16s} {s:4s}: [{v.min():.3f}, {v.max():.3f}] '
              f'{"OK" if good else "VIOLATION"}')

# --- T3: validation targets
# (a) immunocompetent: Nec stays ~0
r_ic = fv.solve_model_vasc_bone(t_span=(0, 504))
nec_ic = r_ic.y[fv.STATE_NAMES_VASC.index('Nec')]
print(f'T3a immunocompetent Nec_end = {nec_ic[-1]:.4f} (target < 0.01): '
      f'{"PASS" if nec_ic[-1] < 0.01 else "FAIL"}')
ok &= nec_ic[-1] < 0.01

# (b) neutropenia untreated: necrosis rises during escape
r_neu = fv.solve_model_vasc_bone(
    t_span=(0, 504), neutropenia={'N_base': 0.05, 'k_N_rec_mult': 0.1})
m_neu = fv.outcome_metrics_vasc(r_neu)
print(f'T3b neutropenic untreated: Nec_end = {m_neu["Nec_end"]:.3f}, '
      f'Nec_peak = {m_neu["Nec_peak"]:.3f}, t_Nec(>0.05) = {m_neu["t_Nec"]} h, '
      f'H_end = {m_neu["H_end"]:.2f}, '
      f'breach ORB/ITF/CS = {m_neu["t_breach_ORB"]}/{m_neu["t_breach_ITF"]}/'
      f'{m_neu["t_breach_CS"]} h')
ok &= m_neu['Nec_end'] > 0.05

# (c) iron overload: vascular invasion at lower burden than immunocompetent
#     (GRP78 axis: same H -> higher E when iron-replete)
r_fe = fv.solve_model_vasc_bone(
    t_span=(0, 504), params_override={'k_Fe_in': f2c.DEFAULT_PARAMS_2C['k_Fe_in'] * 2.0})
E_ic = r_ic.y[fv.STATE_NAMES_VASC.index('E')]
E_fe = r_fe.y[fv.STATE_NAMES_VASC.index('E')]
H_ic = r_ic.y[fv._I_H]; H_fe = r_fe.y[fv._I_H]
print(f'T3c iron x2: E_peak = {E_fe.max():.3f} vs immunocompetent {E_ic.max():.3f}; '
      f'H_peak = {H_fe.max():.2f} vs {H_ic.max():.2f}; '
      f'Nec_end = {r_fe.y[fv.STATE_NAMES_VASC.index("Nec")][-1]:.4f}')

# (d) bone design anchors: all three barriers breach within 21 d, order preserved
tb = [m_neu[f't_breach_{r}'] for r in ('ORB', 'ITF', 'CS')]
anchor = all(np.isfinite(tb)) and tb[0] < tb[1] < tb[2] < 504
print(f'T3d design anchor: breach times {tb} (order ORB<ITF<CS, all <504 h): '
      f'{"PASS" if anchor else "FAIL"}')
ok &= anchor

# (e) phenotype hierarchy: H_end immunocompetent < iron overload << neutropenic
h_ic, h_fe, h_neu = r_ic.y[fv._I_H][-1], r_fe.y[fv._I_H][-1], r_neu.y[fv._I_H][-1]
hier = h_ic < h_fe and h_fe * 10 < h_neu
print(f'T3e hierarchy: H_end {h_ic:.3f} < {h_fe:.3f} << {h_neu:.2f}: '
      f'{"PASS" if hier else "FAIL"}')
ok &= hier

print('\nALL TESTS PASSED' if ok else '\nSOME TESTS FAILED')
