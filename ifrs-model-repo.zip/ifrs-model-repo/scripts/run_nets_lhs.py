#!/usr/bin/env python3
"""25,000-run LHS for the NET-extension model (delivered protocol)."""
import sys, time
sys.path.insert(0, '/mnt/results/ifrs_model')
import pandas as pd
import fungal_sinusitis_nets as fnt

t0 = time.time()
df, corr, perturbed = fnt.run_lhs_nets(n_runs=25000, seed=2026, nets_model='nets',
                                       checkpoint='/workspace/nets_lhs_checkpoint.csv',
                                       checkpoint_every=2500)
df.to_csv('/workspace/ifrs_nets_lhs_runs.csv', index=False)
corr.to_csv('/workspace/ifrs_nets_lhs_correlations.csv')
print(f'LHS done in {time.time()-t0:.0f}s: {len(df)} runs, '
      f'{df["H_end"].notna().sum()} valid ({df["H_end"].isna().mean()*100:.1f}% NaN)')
print('--- key correlations (vs H_end) ---')
for k in ['k_net_form', 'K_net_stim', 'k_net_kill', 'k_net_kill_s', 'k_net_loss',
          'k_Nkill', 'K_kill', 'mu_H', 'k_Fe_in', 'k_up', 'k_seq', 'k_gtx_prod']:
    if k in corr.index:
        print(f'{k:12s}: {corr[k]:+.3f}')
print('done')
