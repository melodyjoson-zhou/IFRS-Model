# IFRS Innate-Immunity ODE Model

Ordinary-differential-equation models of the innate immune response in
invasive fungal rhinosinusitis (IFRS): a 19-state core model (spore
germination chain, iron-dependent hyphal growth, Dectin-1 signaling,
neutrophil/macrophage effectors, IL-10 regulation, fungal countermeasures)
plus five modular extensions — two-compartment spatial proxy (25 states),
bone destruction–deep spread (31), vascular–thrombosis–necrosis chain
(28/34), compartmental iron dynamics (25), and neutrophil extracellular
traps (20) — and a non-uniformity stress test of the aggregate host–pathogen
modifiers.

## Repository structure

```
code/       model modules (core + 5 extensions + stress test)
scripts/    figure-generation and analysis drivers (LHS, stress test)
results/    numerical results (CSV): scenarios, LHS correlations,
            treatment timing, threshold sensitivity, parameter tables
figures/    all figures (PNG + SVG)
notebook/   complete computational notebook (all analyses, in order)
```

## Requirements

Python 3.10+, `numpy`, `scipy`, `pandas`, `matplotlib`
(`pip install -r requirements.txt`).

## Reproducing

Each module runs standalone (`python code/fungal_sinusitis_ode_model.py`
prints the three-host smoke test). The notebook reproduces every figure and
table in the manuscript in order; the stress test reruns end-to-end with
`python scripts/run_lumped_stress.py` (~2 min).

## Model summary

- 168 h acute-phase horizon; innate effectors only (no T-cell state).
- Host scenarios: immunocompetent, diabetes-like iron overload (k_Fe_in x2),
  neutropenia (reduced baseline and recruitment).
- Validation: host stratification against epidemiology, unit tests with
  pointwise regression anchors, 25,000-run Latin hypercube sampling per
  extension, disclosed design choices.
- Aggregate modifiers alpha (immune efficacy), beta (fungal countermeasure
  activity), gamma (IL-10 feedback) are uniform-effect scalars; their
  uniformity assumption is stress-tested in `code/lumped_stress.py`.

## License

Code: MIT. Data and figures: CC-BY 4.0.
