"""fungal_sinusitis_nets.py — Neutrophil extracellular trap (NET) extension
of the IFRS innate-immunity ODE model (round 5).

20 states = core 19 + Tn (NET burden, AU). The core RHS is called verbatim;
the 'nets' mode overlays minimal corrections:

  - NET formation  net_form = k_net_form * Na * gH_net(H) * G_sup
      (activated neutrophils + fungal-stimulus gate + gliotoxin suppression;
       gliotoxin inhibits NADPH oxidase assembly [Tsunawaki 2004], and
       NETosis requires functional NADPH oxidase [Rohm 2014], so the core
       G_sup factor is reused — no new toxin parameters)
  - NET-mediated hyphal damage (minor channel, Bruns 2010 / Clark 2018):
        dH  -= a * k_net_kill   * Tn * H /(K_net_kill + H)
        dHd += same (+ germling channel on Cs)
  - NET-mediated germling damage:
        dCs -= a * k_net_kill_s * Tn * Cs /(K_kills + Cs)
  - dTn = net_form - k_net_loss * Tn

The 'single' mode reproduces the delivered core model exactly (dTn = 0).
"""
import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp

import fungal_sinusitis_ode_model as fsm

_N19 = len(fsm.STATE_NAMES)                        # 19
_I_H = fsm.STATE_NAMES.index('H')
_I_Cs = fsm.STATE_NAMES.index('Cs')
_I_Na = fsm.STATE_NAMES.index('Na')
_I_Hd = fsm.STATE_NAMES.index('Hd')
_I_Gtx = fsm.STATE_NAMES.index('Gtx')

NET_PARAM_META = {
    # rate of NET release given activated neutrophils and fungal stimulus;
    # [lit-ord] NET release completes within ~1-3 h of physiological
    # stimulation (live imaging: Hoppenbrouwers 2017 systematic review;
    # Neubert 2018 Nat Commun three-phase course) -> O(1)/h
    'k_net_form':  (1.0, '/h/AU_Na', 'lit-ord',
                    'NET release within ~1-3 h of stimulation '
                    '(Hoppenbrouwers 2017; Neubert 2018)'),
    # fungal-stimulus half-saturation for NETosis; NETs form at
    # infection-level hyphal load, not at single-spore levels [est]
    'K_net_stim':  (1.0, 'AU', 'est', 'NETosis stimulus gate'),
    # NET-mediated hyphal damage; [est] anchored to the literature consensus
    # that NETs play a minor role in killing A. fumigatus hyphae (Bruns 2010:
    # minor role in killing, may prevent spreading; Clark 2018: PAD4-dependent
    # NETosis not required for hyphal killing) -> ~10% of the k_Nkill channel
    'k_net_kill':  (0.2, '/h/AU_Tn', 'est',
                    'minor hyphal-damage channel (Bruns 2010; Clark 2018)'),
    # saturation of NET-mediated hyphal damage; mirrors K_kill = 10 AU [est]
    'K_net_kill':  (10.0, 'AU', 'est', 'mirrors K_kill'),
    # NET-mediated germling damage; mirrors k_Nkill_s scaled to the minor
    # NET channel [est]
    'k_net_kill_s': (0.1, '/h/AU_Tn', 'est', 'germling channel'),
    # NET decay/clearance; [est with lit-ord bracket] NET structures persist
    # and are cleared over hours (DNase / phagocytic clearance; Urban & Nett
    # 2018 review; Kolman 2022) -> t1/2 ~ 2.3 h
    'k_net_loss':  (0.3, '/h', 'est', 'NET clearance over hours'),
}

DEFAULT_PARAMS_NETS = {**fsm.DEFAULT_PARAMS,
                       **{k: v[0] for k, v in NET_PARAM_META.items()}}
STATE_NAMES_NETS = fsm.STATE_NAMES + ['Tn']
N_STATES_NETS = len(STATE_NAMES_NETS)              # 20
DEFAULT_IC_NETS = {**fsm.DEFAULT_IC, 'Tn': 0.0}


def ode_system_nets(t, y, params, lumped, nets_model='nets'):
    """20-state RHS. nets_model='single' reproduces the delivered core model
    exactly (the core RHS is called verbatim, Tn is bookkeeping zero);
    'nets' applies the minimal NET corrections on top."""
    y19 = y[:_N19]
    Tn = y[_N19]
    p, a = params, lumped['alpha']

    # delivered 19-state RHS, verbatim
    d19 = fsm.ode_system(t, y19, params, lumped).copy()

    if nets_model == 'single':
        return np.concatenate([d19, [0.0]])

    # --- NET corrections ---
    H, Cs, Na, Gtx = y19[_I_H], y19[_I_Cs], y19[_I_Na], y19[_I_Gtx]
    gH_net = H / (p['K_net_stim'] + H)
    # same gliotoxin suppression factor as the core (NADPH-oxidase inhibition)
    G_sup = 1.0 / (1.0 + (Gtx / p['K_gtx']) ** p['n_gtx'])

    net_form = p['k_net_form'] * Na * gH_net * G_sup
    net_kill_H = a * p['k_net_kill'] * Tn * H / (p['K_net_kill'] + H)
    net_kill_s = a * p['k_net_kill_s'] * Tn * Cs / (p['K_kills'] + Cs)

    # NET release is modeled as a function of the activated-neutrophil pool,
    # not a sink: lytic (suicidal) NETosis depletion of Na creates a
    # positive feedback (more fungus -> more NETosis -> fewer effectors ->
    # less killing) that breaks the validated host stratification
    # (iron-overload hosts escape). Vital NETosis and rapid replenishment
    # from the reserve pool on the model's timescale justify the
    # no-depletion choice; disclosed as a simplification.
    # NET-mediated fungal damage (hyphal + germling channels)
    d19[_I_H] -= net_kill_H
    d19[_I_Cs] -= net_kill_s
    d19[_I_Hd] += net_kill_H + net_kill_s

    dTn = net_form - p['k_net_loss'] * Tn
    return np.concatenate([d19, [dTn]])


def solve_model_nets(params=None, lumped=None, ic=None, t_span=(0.0, 168.0),
                     t_eval=None, neutropenia=None, params_override=None,
                     nets_model='nets'):
    """Solve the 20-state NET-extension IFRS model."""
    params = (DEFAULT_PARAMS_NETS.copy() if params is None else params.copy())
    lumped = (fsm.DEFAULT_LUMPED.copy() if lumped is None else lumped.copy())
    ic = (DEFAULT_IC_NETS.copy() if ic is None else ic.copy())
    if t_eval is None:
        t_eval = np.linspace(t_span[0], t_span[1], 841)  # 0.2 h resolution
    if params_override:
        params.update(params_override)
    if neutropenia is not None:
        params = params.copy()
        params['N_base'] = neutropenia.get('N_base', 0.05)
        params['k_N_rec'] = params['k_N_rec'] * neutropenia.get('k_N_rec_mult', 0.1)

    y0 = np.array([ic[name] for name in STATE_NAMES_NETS])
    result = solve_ivp(
        fun=lambda t, y: ode_system_nets(t, y, params, lumped, nets_model),
        t_span=t_span, y0=y0, t_eval=t_eval,
        method='LSODA', rtol=1e-8, atol=1e-10,
    )
    return result


def outcome_metrics_nets(result):
    """Hyphal outcomes (as delivered) + NET outcomes."""
    t = result.t
    H = result.y[_I_H]
    Td = result.y[fsm.STATE_NAMES.index('Td')]
    Tn = result.y[_N19]
    Na = result.y[_I_Na]
    return {
        'H_end': H[-1], 'H_auc': np.trapezoid(H, t), 'H_peak': H.max(),
        'Td_end': Td[-1],
        'Tn_end': Tn[-1], 'Tn_peak': Tn.max(),
        'Na_end': Na[-1],
    }


def run_lhs_nets(n_runs=25000, seed=2026, nets_model='nets',
                 t_span=(0.0, 168.0), n_eval=169, checkpoint=None,
                 checkpoint_every=2500):
    """Latin hypercube sampling over the state parameters, delivered protocol:
    log-uniform 0.1x-10x per parameter. Perturbed set = all PARAM_META entries
    except the fixed one (Td_max) and k_D_phag (excluded in the delivered
    scans), plus the 6 NET parameters."""
    rng = np.random.default_rng(seed)
    base = DEFAULT_PARAMS_NETS.copy()
    perturbed = [k for k, v in fsm.PARAM_META.items() if v[3] != 'fix' and k != 'k_D_phag']
    perturbed += list(NET_PARAM_META.keys())
    n_p = len(perturbed)
    # Latin hypercube: stratified uniform quantiles per parameter
    u = (rng.permuted(np.tile(np.arange(n_runs), (n_p, 1)), axis=1).T
         + rng.random((n_runs, n_p))) / n_runs
    factors = 10.0 ** (u * 2.0 - 1.0)             # 0.1x .. 10x log-uniform
    t_eval = np.linspace(t_span[0], t_span[1], n_eval)
    nan_row = {k: np.nan for k in
               ['H_end', 'H_auc', 'H_peak', 'Td_end', 'Tn_end', 'Tn_peak', 'Na_end']}
    rows = []
    for i in range(n_runs):
        pr = base.copy()
        pr.update({k: base[k] * f for k, f in zip(perturbed, factors[i])})
        try:
            res = solve_model_nets(params=pr, t_span=t_span, t_eval=t_eval,
                                   nets_model=nets_model)
            m = outcome_metrics_nets(res)
        except Exception:
            m = dict(nan_row)
        rows.append({**{k: base[k] * f for k, f in zip(perturbed, factors[i])},
                     **m})
        if checkpoint and (i + 1) % checkpoint_every == 0:
            pd.DataFrame(rows).to_csv(checkpoint, index=False)
    df = pd.DataFrame(rows)
    corr = df.dropna(subset=['H_end']).corr()['H_end']
    return df, corr, perturbed
