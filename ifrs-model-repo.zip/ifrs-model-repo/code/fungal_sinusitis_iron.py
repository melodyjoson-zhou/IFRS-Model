"""
Compartmental iron dynamics for the IFRS innate-immunity ODE model
==================================================================
Three-compartment iron subsystem replacing the single well-mixed free-iron
pool of the delivered core model (fungal_sinusitis_ode_model.py).

MOTIVATION -- fixing a structural artifact. In the delivered single-pool
model, fungal iron uptake (k_up*H*Fe/(K_Fe_H+Fe)) depletes the very pool
that hyphal growth reads (gFe_H on the same Fe), with a constant influx
k_Fe_in as the only source. Uptake rate therefore acts as "pool depletion
speed", not "iron acquisition capacity": in the 25,000-run LHS,
Pearson(k_up, H_end) = -0.150 -- biologically backwards. The sign is an
artifact of the pool architecture (with a fixed influx, faster uptake only
shortens the iron-replete window), not of iron biology.

STRUCTURE -- three compartments:
  Fe_P  plasma / transferrin-bound iron (AU, 1 = normal)
        replenished by influx k_Fe_in, delivered to tissue (k_PT),
        lost to systemic turnover (k_Fe_P_loss; plasma iron disappearance
        t1/2 = 70-105 min in normal subjects, Hosain & Finch 1967 JCI)
  Fe_T  tissue free iron (AU, 1 = normal) -- replaces the delivered Fe
        state; gates germination (gFe_germ), hosts immune sequestration
        (k_seq) and (in future vascular coupling) necrotic iron release
  Fe_F  fungal-side chelated iron (AU) -- siderophore-mediated uptake
        routes iron HERE; hyphal proliferation reads THIS pool
        (gFe_F = Fe_F/(K_Fe_F+Fe_F)) and consumes it with stoichiometry
        sigma_Fe (mycelial iron content ~1 mmol/g dry weight, Misslinger
        2018 Metallomics -> O(1) in normalized units)

Key structural change: uptake ROUTES iron into Fe_F and growth DRAWS from
Fe_F -- "acquisition capacity" and "depletion speed" are decoupled, and the
plasma pool provides the replenishment buffer the single-pool architecture
removed. The developmental transitions (germination gFe_germ, swelling->
hypha k_sw2H) stay gated by environmental Fe_T: spores/germlings have no
siderophore machinery yet (ferricrocin is germination-internal; TAFC is
hyphal, Ribeiro 2022).

Equations (iron_model='three'):
  uptake      = k_up*H*Fe_T/(K_Fe_H+Fe_T)            (delivered flux, rerouted)
  growth_flux = sigma_Fe*mu_H*H*gFe_F*(1-H/K_H)*E_immune
  dFe_P = k_Fe_in - (k_PT + k_Fe_P_loss)*Fe_P + k_TP*Fe_T
  dFe_T = k_PT*Fe_P - k_TP*Fe_T - uptake - seq + k_Fe_F_loss*Fe_F
  dFe_F = uptake - growth_flux - k_Fe_F_loss*Fe_F
  (seq = alpha*k_seq*Fe_T*(1+s_seq*N)*reclaim, exactly as delivered)
  dH growth term: mu_H*gFe_H(Fe_T) -> mu_H*gFe_F(Fe_F); all other core
  equations unchanged (implemented as a minimal correction on the delivered
  RHS, so the single-pool mode is the delivered model by construction).

Conservation bookkeeping (4 cumulative flux states, non-biological):
  Fe_P + Fe_T + Fe_F = init + Fe_in_cum - Fe_ploss_cum - Fe_seq_cum - Fe_growth_cum
  (exact identity at every t, mirroring the 2-compartment fate accounting)

States (25 = 21 biological + 4 bookkeeping):
  core 19 (Fe at index 5 is now tissue free iron Fe_T)
  + Fe_P (19), Fe_F (20)
  + Fe_in_cum (21), Fe_ploss_cum (22), Fe_seq_cum (23), Fe_growth_cum (24)

New parameters (6):
  k_Fe_P_loss = 0.5 /h   lit   plasma iron disappearance t1/2 = 70-105 min
                         (Hosain, Marsaglia & Finch 1967 JCI) -> ln2/1.4 h
  k_TP        = 0.5 /h   est   tissue<->plasma exchange, ~2 h timescale
  k_PT        = 1.0 /h   est   plasma->tissue delivery; set by baseline flux
                         balance k_PT = k_TP + k_Fe_P_loss (structural
                         constraint, not an independent parameter)
  K_Fe_F      = 0.3 AU   est   fungal-side half-saturation (mirrors K_Fe_H)
  sigma_Fe    = 1.0  -   lit-ord  iron cost per AU hyphae; mycelial iron
                         content ~1 mmol/g dry weight (Misslinger 2018)
  k_Fe_F_loss = 0.1 /h   est   fungal iron turnover (dying biomass releases
                         chelated iron back to the tissue pool), ~10 h

Usage:
  from fungal_sinusitis_iron import solve_model_iron, outcome_metrics_iron
  res = solve_model_iron(neutropenia={'N_base': 0.05, 'k_N_rec_mult': 0.1})
  # iron_model='single' reproduces the delivered single-pool model exactly
"""

import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp

import fungal_sinusitis_ode_model as fsm

# ---------------------------------------------------------------------------
# Parameters and initial conditions
# ---------------------------------------------------------------------------
IRON_PARAM_META = {
    'k_Fe_P_loss': (0.5, '/h',   'lit',
                    'plasma iron disappearance t1/2 = 70-105 min in normal subjects '
                    '(Hosain, Marsaglia & Finch 1967 JCI ferrokinetics) -> ln2/1.4 h = 0.5/h'),
    'k_TP':        (0.5, '/h',   'est',
                    'tissue<->plasma iron exchange, ~2 h timescale; ferrokinetics gives plasma '
                    'disappearance but the return flux is distributed across tissues -> structural estimate'),
    'k_PT':        (1.0, '/h',   'est',
                    'plasma->tissue iron delivery; set by baseline flux balance k_PT = k_TP + k_Fe_P_loss '
                    '(holds Fe_P = Fe_T = 1 AU when sequestration is inactive); structural constraint'),
    'K_Fe_F':      (0.3, 'AU',   'est',
                    'fungal-side chelated-iron half-saturation; mirrors K_Fe_H = 0.3 AU (Oremland 2016), '
                    'no separate measurement in these units'),
    'sigma_Fe':    (1.0, '-',    'lit-ord',
                    'iron cost per AU hyphal growth; A. fumigatus mycelia consume ~1 mmol iron/g dry weight '
                    '(Misslinger 2018 Metallomics) -> O(1) in normalized units'),
    'k_Fe_F_loss': (0.1, '/h',   'est',
                    'fungal iron turnover: dying/turning-over biomass releases chelated iron back to the '
                    'tissue pool; ~10 h timescale consistent with hyphal damage/clearance'),
}

DEFAULT_PARAMS_IRON = {**fsm.DEFAULT_PARAMS, **{k: v[0] for k, v in IRON_PARAM_META.items()}}
DEFAULT_IC_IRON = {**fsm.DEFAULT_IC, 'Fe_P': 1.0, 'Fe_F': 0.0,
                   'Fe_in_cum': 0.0, 'Fe_ploss_cum': 0.0,
                   'Fe_seq_cum': 0.0, 'Fe_growth_cum': 0.0}

_N19 = len(fsm.STATE_NAMES)                       # 19
_I_H = fsm.STATE_NAMES.index('H')
_I_Fe = fsm.STATE_NAMES.index('Fe')               # tissue free iron Fe_T
_I_N = fsm.STATE_NAMES.index('N')
_I_Na = fsm.STATE_NAMES.index('Na')
_I_Sid = fsm.STATE_NAMES.index('Sid')
_I_FeP, _I_FeF = _N19, _N19 + 1
_CUM_SLICE = slice(_N19 + 2, _N19 + 6)

STATE_NAMES_IRON = fsm.STATE_NAMES + ['Fe_P', 'Fe_F']
STATE_NAMES_IRON_FULL = STATE_NAMES_IRON + ['Fe_in_cum', 'Fe_ploss_cum',
                                            'Fe_seq_cum', 'Fe_growth_cum']
N_STATES_IRON = len(STATE_NAMES_IRON_FULL)        # 25

VAR_LABELS_IRON = {
    'Fe_P': 'Plasma iron (transferrin-bound)', 'Fe_F': 'Fungal chelated iron',
    'Fe_in_cum': 'Cumulative iron influx', 'Fe_ploss_cum': 'Cumulative plasma loss',
    'Fe_seq_cum': 'Cumulative sequestered iron', 'Fe_growth_cum': 'Cumulative growth consumption',
}


def ode_system_iron(t, y, params, lumped, iron_model='three'):
    """25-state RHS. iron_model='single' reproduces the delivered core model
    exactly (the core RHS is called verbatim); 'three' applies the minimal
    iron-compartment correction on top."""
    y19 = y[:_N19]
    Fe_P, Fe_F = y[_I_FeP], y[_I_FeF]
    p, a = params, lumped['alpha']
    b = lumped['beta']

    # delivered 19-state RHS, verbatim
    d19 = fsm.ode_system(t, y19, params, lumped).copy()

    # shared flux machinery (same formulas as the core model)
    H, Fe_T = y19[_I_H], y19[_I_Fe]
    N, Sid = y19[_I_N], y19[_I_Sid]
    Na = y19[_I_Na]
    reclaim = 1.0 / (1.0 + b * p['s_sid'] * Sid / p['K_sid'])
    seq_flux = a * p['k_seq'] * Fe_T * (1.0 + p['s_seq'] * N) * reclaim
    uptake = p['k_up'] * H * Fe_T / (p['K_Fe_H'] + Fe_T)

    if iron_model == 'single':
        # bookkeeping only: Fe_T = Fe_T0 + cum_in - cum_seq - cum_up
        extras = np.array([p['k_Fe_in'], 0.0, seq_flux, uptake])
        return np.concatenate([d19, [0.0, 0.0], extras])

    # --- three-compartment correction ---
    gFe_T = Fe_T / (p['K_Fe_H'] + Fe_T)          # delivered growth gate (Fe_T)
    gFe_F = Fe_F / (p['K_Fe_F'] + Fe_F)          # new growth gate (fungal pool)
    E_immune = 1.0 / (1.0 + (a * Na / p['K_E']) ** p['h_E'])
    logistic = (1.0 - H / p['K_H'])

    growth_flux = p['sigma_Fe'] * p['mu_H'] * H * gFe_F * logistic * E_immune

    # hyphal proliferation now reads the fungal pool: swap the gate
    d19[_I_H] += p['mu_H'] * H * (gFe_F - gFe_T) * logistic * E_immune

    # tissue iron: replace the influx term by plasma delivery + fungal return
    d19[_I_Fe] += (-p['k_Fe_in'] + p['k_PT'] * Fe_P - p['k_TP'] * Fe_T
                   + p['k_Fe_F_loss'] * Fe_F)

    dFe_P = p['k_Fe_in'] - (p['k_PT'] + p['k_Fe_P_loss']) * Fe_P + p['k_TP'] * Fe_T
    dFe_F = uptake - growth_flux - p['k_Fe_F_loss'] * Fe_F

    extras = np.array([p['k_Fe_in'], p['k_Fe_P_loss'] * Fe_P, seq_flux, growth_flux])
    return np.concatenate([d19, [dFe_P, dFe_F], extras])


def solve_model_iron(params=None, lumped=None, ic=None, t_span=(0.0, 168.0),
                     t_eval=None, neutropenia=None, params_override=None,
                     iron_model='three'):
    """Solve the 25-state compartmental-iron IFRS model."""
    params = (DEFAULT_PARAMS_IRON.copy() if params is None else params.copy())
    lumped = (fsm.DEFAULT_LUMPED.copy() if lumped is None else lumped.copy())
    ic = (DEFAULT_IC_IRON.copy() if ic is None else ic.copy())
    if t_eval is None:
        t_eval = np.linspace(t_span[0], t_span[1], 841)  # 0.2 h resolution
    if params_override:
        params.update(params_override)
    if neutropenia is not None:
        params = params.copy()
        params['N_base'] = neutropenia.get('N_base', 0.05)
        params['k_N_rec'] = params['k_N_rec'] * neutropenia.get('k_N_rec_mult', 0.1)

    y0 = np.array([ic[name] for name in STATE_NAMES_IRON_FULL])
    result = solve_ivp(
        fun=lambda t, y: ode_system_iron(t, y, params, lumped, iron_model),
        t_span=t_span, y0=y0, t_eval=t_eval,
        method='LSODA', rtol=1e-8, atol=1e-10,
    )
    return result


def result_to_dataframe(result):
    df = pd.DataFrame(result.y.T, columns=STATE_NAMES_IRON_FULL)
    df.insert(0, 'time_h', result.t)
    return df


def outcome_metrics_iron(result):
    """Hyphal outcomes (as delivered) + iron-pool outcomes."""
    t = result.t
    H = result.y[_I_H]
    Td = result.y[fsm.STATE_NAMES.index('Td')]
    Fe_T = result.y[_I_Fe]
    Fe_P = result.y[_I_FeP]
    Fe_F = result.y[_I_FeF]
    return {
        'H_end': H[-1], 'H_auc': np.trapezoid(H, t), 'H_peak': H.max(),
        'Td_end': Td[-1],
        'Fe_T_end': Fe_T[-1], 'Fe_T_min': Fe_T.min(),
        'Fe_P_end': Fe_P[-1], 'Fe_P_min': Fe_P.min(),
        'Fe_F_end': Fe_F[-1], 'Fe_F_peak': Fe_F.max(),
    }


def run_lhs_iron(n_runs=25000, seed=2026, iron_model='three',
                 t_span=(0.0, 168.0), n_eval=169, checkpoint=None,
                 checkpoint_every=2500):
    """Latin hypercube sampling over the state parameters, delivered protocol:
    log-uniform 0.1x-10x per parameter. Perturbed set = all PARAM_META entries
    except the fixed one (Td_max) and k_D_phag (excluded in the delivered
    scans), plus the 6 iron parameters."""
    rng = np.random.default_rng(seed)
    base = DEFAULT_PARAMS_IRON.copy()
    perturbed = [k for k, v in fsm.PARAM_META.items() if v[3] != 'fix' and k != 'k_D_phag']
    perturbed += list(IRON_PARAM_META.keys())
    n_p = len(perturbed)
    # Latin hypercube: stratified uniform quantiles per parameter
    u = (rng.permuted(np.tile(np.arange(n_runs), (n_p, 1)), axis=1).T
         + rng.random((n_runs, n_p))) / n_runs
    factors = 10.0 ** (u * 2.0 - 1.0)             # 0.1x .. 10x log-uniform
    t_eval = np.linspace(t_span[0], t_span[1], n_eval)
    rows = []
    for i in range(n_runs):
        pr = base.copy()
        pr.update({k: base[k] * f for k, f in zip(perturbed, factors[i])})
        try:
            res = solve_model_iron(params=pr, t_span=t_span, t_eval=t_eval,
                                   iron_model=iron_model)
            m = outcome_metrics_iron(res)
        except Exception:
            m = {'H_end': np.nan, 'H_auc': np.nan, 'H_peak': np.nan,
                 'Td_end': np.nan, 'Fe_T_end': np.nan, 'Fe_T_min': np.nan,
                 'Fe_P_end': np.nan, 'Fe_P_min': np.nan,
                 'Fe_F_end': np.nan, 'Fe_F_peak': np.nan}
        rows.append({**{k: base[k] * f for k, f in zip(perturbed, factors[i])},
                     **m})
        if checkpoint and (i + 1) % checkpoint_every == 0:
            pd.DataFrame(rows).to_csv(checkpoint, index=False)
    return pd.DataFrame(rows), perturbed


if __name__ == '__main__':
    # smoke test: host stratification under compartmental iron dynamics
    scen = {'immunocompetent': {}, 'iron_overload': {'params_override': {'k_Fe_in': 1.0}},
            'neutropenic': {'neutropenia': {'N_base': 0.05, 'k_N_rec_mult': 0.1}}}
    for name, kw in scen.items():
        res = solve_model_iron(**kw)
        m = outcome_metrics_iron(res)
        print(f"{name:>16s}: H_end={m['H_end']:.3f}  Fe_T_end={m['Fe_T_end']:.3f}  "
              f"Fe_P_min={m['Fe_P_min']:.3f}  Fe_F_peak={m['Fe_F_peak']:.3f}")
