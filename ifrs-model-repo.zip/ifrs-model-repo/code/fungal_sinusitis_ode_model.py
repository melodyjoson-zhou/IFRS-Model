"""
Invasive Fungal Rhinosinusitis (IFRS) Innate Immune Dynamics ODE Model
======================================================================
Mechanistic ODE model of A. fumigatus invasive infection in the sinus
compartment, integrated with the innate immune response.

Framework modeled after Boddepalli, Chhajer & Roy (2026) PLoS Comput Biol
22(6): e1014395 ("Integrative modelling of innate immune response dynamics
during virus infection"), with the virus life cycle replaced by the
A. fumigatus life cycle and the RIG-I/IFN/JAK-STAT cascade replaced by the
Dectin-1/NF-kB/neutrophil-macrophage cascade plus iron nutritional immunity.

State variables (19):
  --- Fungal module ---
  Cl   Conidia in sinus lumen                    (AU, inoculum = 100)
  Cd   Conidia adherent to epithelium            (AU)
  Cs   Swollen conidia / germlings               (AU)
  H    Viable hyphal burden                      (AU)
  Hd   Damaged hyphal material                   (AU)
  Fe   Free iron in tissue                       (AU, 1 = normal)
  BG   Exposed beta-glucan (PAMP signal)         (AU)
  --- Immune sensing / signaling ---
  D    Activated Dectin-1/Card9 signal           (0-1)
  NF   Activated NF-kB                           (0-1)
  Cy   Pro-inflammatory cytokines TNF/IL-1b/GM-CSF (AU)
  Ch   Chemokines CXCL1/2/IL-8                   (AU)
  --- Immune effectors ---
  N    Tissue neutrophils                        (AU, 1 = normal level)
  Na   Activated (ROS/NET-competent) neutrophils (AU)
  M    Tissue macrophages                        (AU, 1 = normal)
  Ma   Activated macrophages                     (AU)
  Il10 IL-10 (anti-inflammatory feedback)        (AU)
  --- Fungal antagonism effectors ---
  Gtx  Gliotoxin burden                          (AU)
  Sid  Siderophore (TAFC) burden                 (AU)
  --- Outcome ---
  Td   Tissue damage                             (0-1)

Lumped tuning parameters (mirror Boddepalli et al.):
  alpha  immune effector potency (killing, phagocytosis, recruitment,
         iron sequestration)
  beta   fungal antagonism strength (gliotoxin, siderophores, masking)
  gamma  host negative-feedback efficiency (IL-10 axis)

Parameter provenance labels:
  [lit]  value or anchor taken from a published source (see sources)
  [lit-ord] order-of-magnitude consistent with published kinetics; exact
         value not identifiable (AU scale), value unchanged from estimate
  [est]  estimated to satisfy qualitative host-status constraints;
         robustness tested by LHS over 0.1x-10x
  [calc] derived from other parameters

Key literature anchors:
  - Hameed et al. 2024 PLoS Comput Biol 20(5):e1012105:
      A. fumigatus hyphal growth rate ~0.36 /h (logistic, fRPMI 37C),
      germination delay tau ~ 5 h.
  - Ribeiro et al. 2022 J R Soc Interface 19:20210806:
      hyphal extension 21-28 um/h; leucocyte activation, recruitment,
      conidial swelling probability, TAFC (siderophore) secretion and
      growth rate are the dominant determinants of burden.
  - Oremland et al. 2016 BMC Syst Biol 10:79:
      neutrophil lifespan 24-48 h; iron influx ~1 unit/h; iron required
      for hyphal growth 0.25 (AU); neutrophils sequester local iron;
      macrophages internalize and kill conidia.
  - Nasal mucociliary clearance t1/2 ~ 30 min (nasal physiology literature;
      same anchor as the user's SAR ODE model k_A = 1.4 /h).

Author: Biomni (for follow-up of the SAR ODE model project)
"""

import numpy as np
from scipy.integrate import solve_ivp
import pandas as pd

# ---------------------------------------------------------------------------
# Parameters (value, unit, provenance, source)
# ---------------------------------------------------------------------------
# Each entry: value / unit / provenance / source
PARAM_META = {
    # --- fungal module: conidia ---
    'k_adh':      (1.8,  '/h',            'lit', '97.5% +/- 0.8% of conidia adherent to bronchial epithelial cells at 2 h, 99.2% at 4 h (Richard 2018, CFU assay); k = -ln(1-0.975)/2 = 1.84 ~ 1.8/h (was 1.2, est)'),
    'k_mcc':      (1.4,  '/h',            'lit', 'nasal mucociliary clearance t1/2 ~ 30 min'),
    'k_phag':     (0.6,  '/h/AU_Ma',      'lit', 'macrophage phagocytosis clears most conidia in 2-4 h (Oremland 2016)'),
    'K_phag':     (20.0, 'AU',            'est', 'phagocytosis saturation'),
    'k_germ':     (0.25, '/h',            'lit', 'germination ~6-8 h post-deposition (Hameed 2024 tau ~ 5 h); swelling starts 4 h post-deposition (Ribeiro 2022 SI Table S1 #58 T_SWELL); 1/4 h'),
    'K_Fe_germ':  (0.3,  'AU',            'lit', 'iron required for growth 0.25 AU (Oremland 2016)'),
    'k_cd_death': (0.02, '/h',            'est', 'conidial natural death'),
    # --- fungal module: hyphae ---
    'k_sw2H':     (0.5,  '/h',            'lit', 'germination ~2 h after swelling (Ribeiro 2022 SI Table S1 #60 ITER_GER; White 1977; Gago 2018); 1/2 h'),
    'mu_H':       (0.36, '/h',            'lit', 'hyphal growth rate (Hameed 2024, logistic per-capita)'),
    'K_Fe_H':     (0.3,  'AU',            'lit', 'iron required for hyphal growth (Oremland 2016)'),
    'K_H':        (500.0,'AU',            'est', 'hyphal carrying capacity in tissue compartment'),
    'K_E':        (5.0,  'AU',            'est', 'immune suppression Hill half-saturation'),
    'h_E':        (3.0,  '-',             'est', 'immune suppression Hill coefficient'),
    'k_Nkill':    (2.0,  '/h/AU_Na',      'lit-ord', 'neutrophil-mediated hyphal damage; RECALIBRATED 1.2->2.0 after literature re-anchoring (k_sw2H=0.5/h, k_Na_act=0.5/h, k_seq=0.15/h) to preserve the phenotype hierarchy immunocompetent clearance < iron-overload intermediate << neutropenic escape; the only recalibrated core parameter; class upgraded to lit-ord: in-vitro assays show neutrophil attachment and severe hyphal damage within 1-2 h co-incubation (Gazendam 2015: efficient hyphal killing in a 1-h assay; Diamond 1978: attachment followed by severe damage), model-implied damage t1/2 ~ 0.7-3.5 h at baseline neutrophils consistent; exact rate not identifiable from % damage assays at non-standardized effector:target ratios'),
    'K_kill':     (10.0, 'AU',            'est', 'killing saturation'),
    'k_Nkill_s':  (0.8,  '/h/AU_Na',      'lit-ord', 'neutrophil damage to germlings; same in-vitro hour-scale damage bracket as k_Nkill (Diamond 1978; Gazendam 2015); exact rate not identifiable'),
    'K_kills':    (10.0, 'AU',            'est', 'germling killing saturation'),
    'k_H_death':  (0.02, '/h',            'est', 'hyphal natural death'),
    'k_Hd_clear': (0.1,  '/h',            'est', 'damaged hyphal material clearance'),
    # --- iron ---
    'k_Fe_in':    (0.5,  'AU/h',          'lit', 'iron influx ~1 unit/h (Oremland 2016, rescaled)'),
    'k_seq':      (0.15, '/h',            'lit', 'lactoferrin injection lowers serum iron 46% in 4 h -> k=ln(1/0.54)/4=0.15/h (Ribeiro 2022 SI S2.7, citing ref 31)'),
    's_seq':      (1.0,  '-',             'lit', 'neutrophils sequester local iron (Oremland 2016)'),
    'k_up':       (0.5,  '/h/AU_H',       'est', 'fungal iron uptake from free-iron pool'),
    's_sid':      (1.5,  '-',             'lit', 'siderophores reclaim host-sequestered iron (Ribeiro 2022 TAFC)'),
    'K_sid':      (1.0,  'AU',            'est', 'siderophore reclaim half-saturation'),
    # --- PAMP exposure ---
    'k_BG_H':     (0.5,  '/h',            'lit-ord', 'beta-glucan exposure from hyphae; beta-glucan surface-exposed during swelling (3-5 h) and prominent on early germlings (7 h) (Hohl 2005); hour-scale exposure consistent; exact rate not identifiable'),
    'k_BG_s':     (0.2,  '/h',            'lit-ord', 'beta-glucan exposure from germlings; stage-specific display across the 3-7 h germination window (Hohl 2005); t1/2 ~ 3.5 h consistent'),
    's_mask':     (0.8,  '-',             'lit', 'resting conidia mask beta-glucan (literature)'),
    'k_BG_clear': (1.0,  '/h',            'est', 'PAMP clearance'),
    # --- sensing / signaling ---
    'k_D_phag':   (1.0,  '/h/AU_flux',  'est', 'phagocytosed conidia activate macrophages via Dectin-1 (structural fix; value estimated)'),
    'k_D':        (2.0,  '/h',            'lit-ord', 'Dectin-1/Syk activation within minutes of beta-glucan engagement (Goodridge 2011); t1/2 ~ 21 min consistent; exact rate not identifiable'),
    'k_Doff':     (0.5,  '/h',            'lit-ord', 'Dectin-1 signal decay on tens-of-minutes scale (Goodridge 2011 phagocytic synapse); t1/2 ~ 83 min consistent'),
    'k_NF':       (3.0,  '/h',            'lit-ord', 'NF-kB nuclear translocation within minutes of TNF stimulation (Nelson 2002; Ding 1998); t1/2 ~ 14 min consistent'),
    'k_NF_off':   (1.0,  '/h',            'lit-ord', 'NF-kB export / IkBa feedback on tens-of-minutes scale (Nelson 2002); t1/2 ~ 42 min consistent'),
    'K_il10':     (2.0,  'AU',            'est', 'IL-10 repression half-saturation'),
    'n_il10':     (2.0,  '-',             'est', 'IL-10 repression Hill coefficient'),
    'k_Cy':       (5.0,  'AU/h',          'est', 'cytokine production by NF-kB'),
    'k_Cy_clear': (1.4,  '/h',            'lit', 'TNF t1/2 ~ 30 min'),
    'k_Ch':       (3.0,  'AU/h',          'est', 'chemokine production'),
    'k_Ch_clear': (0.7,  '/h',            'lit', 'chemokine t1/2 ~ 1 h'),
    # --- neutrophils ---
    'k_N_base':   (0.25, '/h',            'lit', 'neutrophil homeostatic turnover'),
    'N_base':     (1.0,  'AU',            'lit', 'normal tissue neutrophil level (normalized)'),
    'k_N_rec':    (1.0,  '/h/AU_Ch',      'est', 'chemokine-driven recruitment; Ribeiro 2022 SI Table S1 #73 REC_RT = 2/h is not transferable (their term uses dimensionless chemokine occupancy X/k_d, ours uses AU_Ch), so the value remains estimated'),
    'N_max':      (10.0, 'AU',            'lit-ord', 'max tissue neutrophil expansion; live-conidia BAL influx ~8-9 fold over dormant-conidia control at 24 h in mice (Hohl 2005); N_max/N_base = 10 consistent order'),
    'k_N_apop':   (0.03, '/h',            'lit', 'neutrophil lifespan 24-48 h (Oremland 2016)'),
    'k_Na_act':   (0.5,  '/h',            'lit', 'leukocyte state change ~2 h (Ribeiro 2022 SI Table S1 #61 ITER_CH_ST, in-vitro reports); 1/2 h'),
    'K_gtx':      (1.0,  'AU',            'est', 'gliotoxin suppression half-saturation'),
    'n_gtx':      (2.0,  '-',             'est', 'gliotoxin Hill coefficient'),
    'k_Na_deact': (0.17, '/h',            'lit', 'active cells return to resting after ~6 h (Ribeiro 2022 SI Table S1 #62 INTER_REST, in-vitro reports); 1/6 h'),
    # --- macrophages ---
    'k_M_base':   (0.029,'/h',            'lit', 'monocyte/macrophage half-life 24 h -> ln2/24 (Ribeiro 2022 SI Table S1 #54)'),
    'M_base':     (1.0,  'AU',            'lit', 'normal resident macrophage level (normalized)'),
    'k_M_rec':    (0.1,  '/h/AU_Cy',      'lit', 'monocytes predominate in infiltrate 12-24 h after neutrophils (Issekutz 1993; Rodero 2014); recruitment time constant ~10 h at Cy=1 AU'),
    'M_max':      (5.0,  'AU',            'est', 'max tissue macrophage expansion'),
    'k_M_off':    (0.05, '/h',            'lit', 'macrophage tissue residence days'),
    'k_Ma_act':   (0.5,  '/h',            'lit', 'leukocyte state change ~2 h (Ribeiro 2022 SI Table S1 #61 ITER_CH_ST)'),
    'k_Ma_deact': (0.17, '/h',            'lit', 'return to resting ~6 h (Ribeiro 2022 SI Table S1 #62 INTER_REST); 1/6 h'),
    # --- feedback / antagonism effectors ---
    'k_il10_prod':(0.5,  'AU/h',          'est', 'IL-10 production by activated effectors'),
    'k_il10_clear':(0.7, '/h',            'lit', 'IL-10 t1/2 ~ 1 h'),
    'k_gtx_prod': (0.3,  'AU/h',          'est', 'gliotoxin production by hyphae'),
    'k_gtx_clear':(0.5,  '/h',            'est', 'gliotoxin clearance'),
    'k_sid_prod': (0.3,  'AU/h',          'est', 'siderophore (TAFC) secretion by hyphae'),
    'k_sid_clear':(0.5,  '/h',            'est', 'siderophore clearance'),
    # --- tissue damage ---
    'k_td':       (0.1,  '/h',            'est', 'damage accumulation from hyphal burden'),
    'Td_max':     (1.0,  '-',             'fix', 'normalized max tissue damage'),
    'k_repair':   (0.004,'/h',            'lit', 'sinonasal mucosa recovery: >90% cavities clean 1-2 weeks post-injury (Xu 1999; Xu 2008); t1/2 ~ 7 d -> ln2/168h'),
}

DEFAULT_PARAMS = {k: v[0] for k, v in PARAM_META.items()}

# Lumped tuning parameters (kept separate from PARAM_META)
DEFAULT_LUMPED = {'alpha': 1.0, 'beta': 1.0, 'gamma': 1.0}

DEFAULT_IC = {
    'Cl': 100.0,  # inoculum (AU); MOI variants scale this
    'Cd': 0.0, 'Cs': 0.0, 'H': 0.0, 'Hd': 0.0,
    'Fe': 1.0,    # normal free iron
    'BG': 0.0,
    'D': 0.0, 'NF': 0.0, 'Cy': 0.0, 'Ch': 0.0,
    'N': 1.0, 'Na': 0.0,
    'M': 1.0, 'Ma': 0.0,
    'Il10': 0.0, 'Gtx': 0.0, 'Sid': 0.0, 'Td': 0.0,
}

STATE_NAMES = ['Cl', 'Cd', 'Cs', 'H', 'Hd', 'Fe', 'BG', 'D', 'NF', 'Cy',
               'Ch', 'N', 'Na', 'M', 'Ma', 'Il10', 'Gtx', 'Sid', 'Td']

VAR_LABELS = {
    'Cl': 'Conidia (lumen)', 'Cd': 'Conidia (adherent)', 'Cs': 'Germlings',
    'H': 'Hyphal burden', 'Hd': 'Damaged hyphae', 'Fe': 'Free iron',
    'BG': 'beta-glucan (PAMP)', 'D': 'Dectin-1 signal', 'NF': 'NF-kB',
    'Cy': 'Cytokines', 'Ch': 'Chemokines', 'N': 'Neutrophils',
    'Na': 'Activated neutrophils', 'M': 'Macrophages',
    'Ma': 'Activated macrophages', 'Il10': 'IL-10',
    'Gtx': 'Gliotoxin', 'Sid': 'Siderophore', 'Td': 'Tissue damage',
}


def ode_system(t, y, params, lumped, events=None):
    """
    19-dimensional IFRS ODE system.

    Lumped parameters (Boddepalli-style uniform-effect assumption):
      alpha  scales immune effector action on the fungus:
             phagocytosis (k_phag), neutrophil killing (k_Nkill, k_Nkill_s),
             iron sequestration (k_seq), chemokine-driven recruitment (k_N_rec)
      beta   scales fungal antagonism:
             gliotoxin production (k_gtx_prod), siderophore secretion
             (k_sid_prod), conidial beta-glucan masking (s_mask)
      gamma  scales IL-10 negative-feedback production (k_il10_prod)
    """
    (Cl, Cd, Cs, H, Hd, Fe, BG, D, NF, Cy,
     Ch, N, Na, M, Ma, Il10, Gtx, Sid, Td) = y
    p = params
    a = lumped['alpha']
    b = lumped['beta']
    g = lumped['gamma']

    # iron availability functions
    gFe_germ = Fe / (p['K_Fe_germ'] + Fe)      # germination iron dependence
    gFe_H = Fe / (p['K_Fe_H'] + Fe)            # hyphal extension iron dependence

    # siderophores reclaim host-sequestered iron (blunt sequestration);
    # without them, sequestered iron is inaccessible to the fungus
    reclaim = 1.0 / (1.0 + b * p['s_sid'] * Sid / p['K_sid'])

    # immune suppression of hyphal extension (Hill; mirrors ISG Hill repression)
    E_immune = 1.0 / (1.0 + (a * Na / p['K_E']) ** p['h_E'])

    # gliotoxin suppression of leucocyte activation (Hill)
    G_sup = 1.0 / (1.0 + (Gtx / p['K_gtx']) ** p['n_gtx'])

    # IL-10 repression of NF-kB (Hill; gamma-scaled feedback)
    IL10_rep = 1.0 / (1.0 + (g * Il10 / p['K_il10']) ** p['n_il10'])

    # conidial beta-glucan masking (beta-scaled)
    mask = 1.0 - b * p['s_mask'] * (Cd / (p['K_phag'] + Cd))
    mask = max(mask, 0.0)

    # --- fungal module ---
    dCl = -p['k_adh'] * Cl - p['k_mcc'] * Cl
    dCd = (p['k_adh'] * Cl
           - a * p['k_phag'] * Ma * Cd / (p['K_phag'] + Cd)
           - p['k_germ'] * Cd * gFe_germ
           - p['k_cd_death'] * Cd)
    dCs = (p['k_germ'] * Cd * gFe_germ
           - p['k_sw2H'] * Cs * gFe_H
           - a * p['k_phag'] * Ma * Cs / (p['K_phag'] + Cs)
           - a * p['k_Nkill_s'] * Na * Cs / (p['K_kills'] + Cs))
    dH = (p['k_sw2H'] * Cs * gFe_H
          + p['mu_H'] * H * gFe_H * (1.0 - H / p['K_H']) * E_immune
          - a * p['k_Nkill'] * Na * H / (p['K_kill'] + H)
          - p['k_H_death'] * H)
    dHd = (a * p['k_Nkill'] * Na * H / (p['K_kill'] + H)
           + a * p['k_Nkill_s'] * Na * Cs / (p['K_kills'] + Cs)
           - p['k_Hd_clear'] * Hd)
    dFe = (p['k_Fe_in']
           - a * p['k_seq'] * Fe * (1.0 + p['s_seq'] * N) * reclaim
           - p['k_up'] * H * Fe / (p['K_Fe_H'] + Fe))
    dBG = (p['k_BG_H'] * H + p['k_BG_s'] * Cs * mask
           - p['k_BG_clear'] * BG)

    # --- sensing / signaling ---
    # phagocytosis of conidia feeds Dectin-1 signaling (intracellular
    # recognition of ingested conidia activates macrophages)
    phag_flux = a * p['k_phag'] * Ma * Cd / (p['K_phag'] + Cd)
    dD = p['k_D'] * BG * (1.0 - D) - p['k_Doff'] * D + p['k_D_phag'] * phag_flux * G_sup
    dNF = p['k_NF'] * D * (1.0 - NF) * IL10_rep - p['k_NF_off'] * NF
    dCy = p['k_Cy'] * NF - p['k_Cy_clear'] * Cy
    dCh = p['k_Ch'] * NF - p['k_Ch_clear'] * Ch

    # --- effectors ---
    dN = (p['k_N_base'] * (p['N_base'] - N)
          + a * p['k_N_rec'] * Ch * (1.0 - N / p['N_max'])
          - p['k_N_apop'] * N)
    dNa = p['k_Na_act'] * Cy * (N - Na) * G_sup - p['k_Na_deact'] * Na
    dM = (p['k_M_base'] * (p['M_base'] - M)
          + p['k_M_rec'] * Cy * (1.0 - M / p['M_max'])
          - p['k_M_off'] * M)
    dMa = p['k_Ma_act'] * D * (M - Ma) * G_sup - p['k_Ma_deact'] * Ma
    dIl10 = g * p['k_il10_prod'] * (Na + Ma) - p['k_il10_clear'] * Il10

    # --- fungal antagonism effectors ---
    dGtx = b * p['k_gtx_prod'] * H - p['k_gtx_clear'] * Gtx
    dSid = b * p['k_sid_prod'] * H - p['k_sid_clear'] * Sid

    # --- outcome ---
    dTd = p['k_td'] * H * (1.0 - Td / p['Td_max']) - p['k_repair'] * Td

    return np.array([dCl, dCd, dCs, dH, dHd, dFe, dBG, dD, dNF, dCy,
                     dCh, dN, dNa, dM, dMa, dIl10, dGtx, dSid, dTd])


def solve_model(params=None, lumped=None, ic=None, t_span=(0.0, 168.0),
                t_eval=None, neutropenia=None, params_override=None):
    """
    Solve the IFRS ODE model.

    Parameters
    ----------
    params : dict or None
    lumped : dict or None (alpha, beta, gamma)
    ic : dict or None
    t_span : (t0, t1) in hours; default 0-168 h (7 days)
    t_eval : array-like or None
    neutropenia : dict or None
        {'N_base': 0.05, 'k_N_rec_mult': 0.1} overrides for neutropenic host.
        Immune reconstitution can be modeled by solving in two segments.
    """
    params = (DEFAULT_PARAMS.copy() if params is None else params.copy())
    lumped = (DEFAULT_LUMPED.copy() if lumped is None else lumped.copy())
    ic = (DEFAULT_IC.copy() if ic is None else ic.copy())
    if t_eval is None:
        t_eval = np.linspace(t_span[0], t_span[1], 841)  # 0.2 h resolution

    # generic parameter overrides (e.g. iron overload: k_Fe_in x4)
    if params_override:
        params.update(params_override)

    if neutropenia is not None:
        params = params.copy()
        params['N_base'] = neutropenia.get('N_base', 0.05)
        params['k_N_rec'] = params['k_N_rec'] * neutropenia.get('k_N_rec_mult', 0.1)

    y0 = np.array([ic[name] for name in STATE_NAMES])

    result = solve_ivp(
        fun=lambda t, y: ode_system(t, y, params, lumped),
        t_span=t_span, y0=y0, t_eval=t_eval,
        method='LSODA', rtol=1e-8, atol=1e-10,
    )
    return result


def result_to_dataframe(result):
    df = pd.DataFrame(result.y.T, columns=STATE_NAMES)
    df.insert(0, 'time_h', result.t)
    return df


def outcome_metrics(result):
    """Key outcomes: hyphal burden at end, hyphal AUC, tissue damage, peak H."""
    t = result.t
    H = result.y[STATE_NAMES.index('H')]
    Td = result.y[STATE_NAMES.index('Td')]
    return {
        'H_end': H[-1],
        'H_auc': np.trapezoid(H, t),
        'H_peak': H.max(),
        'Td_end': Td[-1],
    }


# ---------------------------------------------------------------------------
# Host-status scenarios (validation targets)
# ---------------------------------------------------------------------------
HOST_SCENARIOS = {
    # immunocompetent: normal neutrophils, normal iron, wild-type fungus
    'immunocompetent': {},
    # prolonged neutropenia (the dominant clinical risk factor for IFRS)
    'neutropenic': {'neutropenia': {'N_base': 0.05, 'k_N_rec_mult': 0.1}},
    # diabetic ketoacidosis-like iron liberation (moderate 2x; strong 4x
    # overload causes escape even in immunocompetent hosts, which is
    # epidemiologically too strong for aspergillosis)
    'iron_overload': {'params_override': {'k_Fe_in': 1.0}},
}


if __name__ == '__main__':
    # quick smoke test
    for name, kw in HOST_SCENARIOS.items():
        res = solve_model(**kw) if kw else solve_model()
        m = outcome_metrics(res)
        print(f"{name:>16s}: H_end={m['H_end']:.3f}  H_auc={m['H_auc']:.1f}  "
              f"Td_end={m['Td_end']:.3f}")
