"""
Bone destruction -- deep-space spread module (three anatomical routes) for the
IFRS two-compartment spatial proxy.

Motivation: IFRS/ROCM commonly breaches bony barriers to reach deep spaces --
lamina papyracea -> orbit (ORB), posterior maxillary wall -> infratemporal
fossa (ITF), sphenoid/clivus region -> cavernous sinus / intracranial (CS) --
which drives the lethal trajectory of the disease (intracranial extension:
mortality 71.4% vs 28.9% without, Gunay Kozan 2025; CNS involvement death
HR = 6.71, Nagarkar 2023). This module extends the 25-state two-compartment
model (fungal_sinusitis_2comp) with 6 states: for each route i, bone barrier
integrity B_i in [0,1] and deep-space fungal burden D_i.

Dynamics (ONE-WAY coupling H -> bone/deep states; the 25-state tissue
trajectory is IDENTICAL to the plain two-compartment model -- unit-tested):

  dB_i/dt = -k_bone_i * H^2/(K_Hb^2 + H^2) * B_i
      bone destruction proportional to remaining integrity, saturating (Hill
      n=2) in the tissue hyphal burden H: destruction requires SUBSTANTIAL
      burden -- the persistent low-grade tail (H ~ 0.04 AU) of resolved
      disease in immunocompetent hosts must NOT erode barriers over weeks

  dD_i/dt = (k_inv*(1 - B_i) + k_angio_i) * H + (mu_H - k_Ddeath) * D_i
      direct route: the same invasion constant k_inv as tissue entry, gated by
      barrier breach (1 - B_i);
      angioinvasive route: NOT gated by the barrier (spread via vascular
      channels with intact bone on imaging -- Deshmukh 2022); in this minimal
      model angio-only seeding stays SUB-establishment at the tissue plateau
      (barrier breach is the gatekeeper for established deep invasion, hence
      bone dehiscence is the key CT staging landmark -- Middlebrooks 2015,
      Gunay Kozan 2025); its role is barrier-independent priming that
      accelerates establishment once barriers are compromised;
      deep spaces are immune-poor: growth shares mu_H (antifungal-responsive),
      opposed by nonspecific loss k_Ddeath (not neutrophil-dependent). The
      k_Ddeath term is REQUIRED for containment: without it, even the tiny
      angioinvasive seeding in an immunocompetent host (H ~ 0.04 AU) would
      grow without bound. Net deep growth = mu_H - k_Ddeath < 0, so deep-space
      disease only establishes when tissue seeding is sustained (tissue
      escape), inheriting the tissue outcome through the seeding flux.

New parameters (7, all estimated; qualitative anchors documented):
  k_bone_ORB = 0.008 /h   lamina papyracea 0.2-0.4 mm, thinnest bone in the
                          body -> fastest breach
  k_bone_ITF = 0.005 /h   posterior maxillary wall (cortical, thicker)
  k_bone_CS  = 0.004 /h   skull base / clivus region (thickest cortical);
                          RECALIBRATED 0.003->0.004 after core-model literature
                          re-anchoring (slower immune activation, faster
                          germination) lowered the untreated neutropenic
                          tissue-burden plateau; preserves the design anchor
                          (all barriers breach within ~3 weeks) and the
                          clinical order ORB < ITF < CS (128/215/330 h)
      scale: untreated neutropenic host (H -> plateau ~20 AU) -> B_ORB
      half-life ~ 4 d at H = 10; all three barriers breach within ~3 weeks
      (calibration target; deaths occur at median 16 d -- Nagarkar)
  k_angio_ORB = 0.006, k_angio_ITF = 0.003, k_angio_CS = 0.0015  (1/(AU*h))
      vascular seeding, ordered ORB > ITF > CS to match the clinical
      frequency/timing anchor (orbital extension 48% >> CNS 15% at
      presentation; intracranial involvement occurs later -- Nagarkar 2023,
      Voruz 2025)
  k_Ddeath    = 0.5 /h    nonspecific deep-space fungal loss
  K_Hb = 5.0 AU           Hill constant (n=2) of bone destruction: the
                          immunocompetent transient (H_peak ~0.97 AU) causes
                          <2% erosion, escape-level burden (H ~14 AU) causes
                          breach within days

Route-ordering calibration target (Nagarkar 2023; Voruz 2025): at presentation
orbital extension (48%) >> CNS extension (15%); intracranial involvement
occurs LATER in the disease course: t_breach_ORB < t_breach_ITF < t_breach_CS
and t_deep_ORB < t_deep_ITF < t_deep_CS in the untreated neutropenic host.
"""
import numpy as np
from scipy.integrate import solve_ivp

import fungal_sinusitis_ode_model as fsm
import fungal_sinusitis_2comp as f2c

DEFAULT_PARAMS_BONE = f2c.DEFAULT_PARAMS_2C.copy()
DEFAULT_PARAMS_BONE.update({
    'k_bone_ORB': 0.008,   # /h, lamina papyracea breach (est)
    'k_bone_ITF': 0.005,   # /h, posterior maxillary wall breach (est)
    'k_bone_CS':  0.004,   # /h, skull base / clivus breach (est; recalibrated 0.003->0.004 after core re-anchoring)
    'k_angio_ORB': 0.006,  # 1/(AU h), vascular seeding of orbit (est)
    'k_angio_ITF': 0.003,  # 1/(AU h), vascular seeding of ITF (est)
    'k_angio_CS':  0.0015, # 1/(AU h), vascular seeding of cavernous sinus (est)
    'k_Ddeath':   0.5,     # /h, nonspecific deep-space fungal loss (est)
    'K_Hb':       5.0,     # AU, Hill constant: separates the sub-clinical
                           # transient (IC H_peak ~0.97 AU -> gH 0.036) from
                           # escape-level burden (H ~14 AU -> gH 0.89)
})

BONE_NAMES = ['B_ORB', 'D_ORB', 'B_ITF', 'D_ITF', 'B_CS', 'D_CS']
STATE_NAMES_BONE = f2c.STATE_NAMES_FULL + BONE_NAMES  # 31 states
N_BONE = 6

DEFAULT_IC_BONE = f2c.DEFAULT_IC_2C.copy()
DEFAULT_IC_BONE.update({'B_ORB': 1.0, 'D_ORB': 0.0,
                        'B_ITF': 1.0, 'D_ITF': 0.0,
                        'B_CS': 1.0, 'D_CS': 0.0})

# states reduced stepwise by surgical debridement (surgical field = lumen +
# tissue fungal chain): luminal conidia/germlings + tissue fungal chain
DEBRIDED_STATES = ['Cl_L', 'Cd_L', 'Cs_L', 'Cl', 'Cd', 'Cs', 'H', 'Hd']

_H_IX = f2c.N_LUMEN + fsm.STATE_NAMES.index('H')       # tissue hyphae index
_I_H = fsm.STATE_NAMES.index('H')
_ROUTES = {'ORB': ('k_bone_ORB', 'k_angio_ORB'),
           'ITF': ('k_bone_ITF', 'k_angio_ITF'),
           'CS':  ('k_bone_CS',  'k_angio_CS')}


def ode_system_bone(t, y, params, lumped):
    """31-state RHS: 25-state two-compartment model (verbatim) + 6 bone states."""
    p = params
    d25 = f2c.ode_system_2c(t, y[:len(f2c.STATE_NAMES_FULL)], p, lumped)
    H = y[_H_IX]
    gH = H**2 / (p['K_Hb']**2 + H**2)  # Hill n=2: destruction needs substantial burden
    mu_net = p['mu_H'] - p['k_Ddeath']  # net deep-space growth (antifungal-responsive)
    d_bone = []
    for j, (kb, ka) in enumerate(_ROUTES.values()):
        B, D = y[len(f2c.STATE_NAMES_FULL) + 2 * j], y[len(f2c.STATE_NAMES_FULL) + 2 * j + 1]
        d_bone += [-p[kb] * gH * B,                       # dB_i/dt
                   (p['k_inv'] * (1.0 - B) + p[ka]) * H + mu_net * D]  # dD_i/dt
    return np.concatenate([d25, d_bone])


def solve_model_bone(params=None, lumped=None, ic=None, t_span=(0.0, 504.0),
                     t_eval=None, neutropenia=None, params_override=None,
                     mucociliary=None):
    """Solve the 31-state bone-spread model (interface mirrors solve_model_2c)."""
    params = (DEFAULT_PARAMS_BONE.copy() if params is None else params.copy())
    lumped = ({'alpha': 1.0, 'beta': 1.0, 'gamma': 1.0} if lumped is None
              else lumped.copy())
    ic = (DEFAULT_IC_BONE.copy() if ic is None else ic.copy())
    if t_eval is None:
        t_eval = np.linspace(t_span[0], t_span[1], 1261)  # 0.4 h resolution
    if params_override:
        params.update(params_override)
    if mucociliary is not None:
        params['k_mcc'] = params['k_mcc'] * mucociliary.get('k_mcc_mult', 1.0)
    if neutropenia is not None:
        params['N_base'] = neutropenia.get('N_base', 0.05)
        params['k_N_rec'] = params['k_N_rec'] * neutropenia.get('k_N_rec_mult', 0.1)

    y0 = np.array([ic[name] for name in STATE_NAMES_BONE])
    return solve_ivp(
        fun=lambda t, y: ode_system_bone(t, y, params, lumped),
        t_span=t_span, y0=y0, t_eval=t_eval,
        method='LSODA', rtol=1e-8, atol=1e-10,
    )


def simulate_bone_intervention(t_af=None, eff=0.0, t_deb=None, deb_frac=0.9,
                               t_rec=None, neutropenic=False, lumped=None,
                               t_span=(0.0, 504.0), t_eval=None,
                               params_override=None, mucociliary=None):
    """Piecewise 31-state simulation with three intervention types:
    antifungal (mu_H x (1-eff)) from t_af; surgical debridement (step reduction
    of the fungal chain by deb_frac) at t_deb; neutropenia lifted from t_rec.
    params_override / mucociliary define the HOST background (applied to every
    segment, mirroring solve_model_2c / solve_model_bone semantics).
    Returns t (N,), Y (N, 31) in STATE_NAMES_BONE order."""
    L = lumped or {'alpha': 1.0, 'beta': 1.0, 'gamma': 1.0}
    onsets = [t for t in ((t_af if eff > 0 else None), t_deb, t_rec) if t is not None]
    events = sorted({0.0, t_span[1]} | {max(0.0, t) for t in onsets})
    if t_eval is None:
        t_eval = np.linspace(t_span[0], t_span[1], 1261)
    y0, ts, ys = None, [], []
    for t0, t1 in zip(events[:-1], events[1:]):
        if t1 - t0 < 1e-9:
            continue
        p = DEFAULT_PARAMS_BONE.copy()
        if params_override:
            p.update(params_override)
        if mucociliary is not None:
            p['k_mcc'] = p['k_mcc'] * mucociliary.get('k_mcc_mult', 1.0)
        if eff > 0 and t_af is not None and t0 >= max(t_af, 0.0) - 1e-9:
            p['mu_H'] *= (1.0 - eff)
        neu = neutropenic and (t_rec is None or t0 < t_rec - 1e-9)
        kw = dict(params=p, lumped=L, t_span=(t0, t1),
                  t_eval=t_eval[(t_eval >= t0 - 1e-9) & (t_eval <= t1 + 1e-9)])
        if y0 is None:
            ic = DEFAULT_IC_BONE.copy()
            if t_deb is not None and t0 >= max(t_deb, 0.0) - 1e-9:
                for nm in DEBRIDED_STATES:
                    ic[nm] *= (1.0 - deb_frac)
            kw['ic'] = ic
        else:
            if t_deb is not None and abs(t0 - max(t_deb, 0.0)) < 1e-9:
                y0 = y0.copy()
                for nm in DEBRIDED_STATES:
                    y0[nm] *= (1.0 - deb_frac)
            kw['ic'] = y0
        if neu:
            kw['neutropenia'] = {'N_base': 0.05, 'k_N_rec_mult': 0.1}
        r = solve_model_bone(**kw)
        y0 = {nm: r.y[j][-1] for j, nm in enumerate(STATE_NAMES_BONE)}
        ts.append(r.t); ys.append(r.y.T)
    t_c = np.concatenate(ts); Y_c = np.concatenate(ys, axis=0)
    keep = np.concatenate([[True], np.diff(t_c) > 1e-9])
    return t_c[keep], Y_c[keep]


def outcome_metrics_bone(result, t_horizon=None):
    """Bone/deep-space outcomes per route: breach time (B_i crosses 0.5),
    establishment time (D_i crosses 1 AU), end values. NaN = never within
    the simulated horizon."""
    t = result.t
    n25 = len(f2c.STATE_NAMES_FULL)
    out = {'H_end': result.y[_H_IX][-1],
           'H_auc': np.trapezoid(result.y[_H_IX], t)}
    for j, route in enumerate(_ROUTES):
        B = result.y[n25 + 2 * j]
        D = result.y[n25 + 2 * j + 1]
        ib = np.argmax(B < 0.5) if (B < 0.5).any() else -1
        idd = np.argmax(D > 1.0) if (D > 1.0).any() else -1
        out[f't_breach_{route}'] = t[ib] if ib >= 0 else np.nan
        out[f't_deep_{route}'] = t[idd] if idd >= 0 else np.nan
        out[f'B_end_{route}'] = B[-1]
        out[f'D_end_{route}'] = D[-1]
    return out
