"""
Minimal two-compartment spatial proxy (nasal lumen <-> sinus tissue) for the
IFRS innate-immune ODE model.

Motivation: the delivered 19-state model (fungal_sinusitis_ode_model) is a
single well-mixed pool. This module addresses the reviewer concern about the
0-dimensional structure by splitting the fungal chain into a true LUMEN
(where mucociliary clearance acts) and TISSUE (the delivered 19-state
dynamics, reused unchanged via fsm.ode_system with k_mcc = 0 -- mucociliary
clearance does not act on tissue-invasive fungus).

Lumen states (3):
  Cl_L  free conidia in the mucus stream : adhere (k_adh) or cleared (k_mcc)
  Cd_L  conidia adherent to epithelium   : germinate (k_germ, iron-limited by
          low airway-surface-liquid iron Fe_L) or die (k_cd_death);
          adherent conidia evade mucociliary transport
  Cs_L  lumen germlings                  : invade tissue (k_inv) or die
          (k_cd_death; exposure to airway antimicrobial factors)

Tissue states (19): exactly fungal_sinusitis_ode_model.STATE_NAMES; the
  invasion flux k_inv * Cs_L seeds tissue germlings (Cs_T). Tissue conidia
  (Cl_T, Cd_T) have no source in this design and remain at zero.

New parameters (2, both estimated; swept in the accompanying analyses):
  k_inv = 0.1 /h    epithelial invasion timescale ~10 h
  Fe_L  = 0.05 AU   airway-surface-liquid free iron (~5% of tissue level)

Design choices (documented for review response):
  * k_mcc acts ONLY on luminal free conidia -- anatomical fix relative to the
    0-D model, where clearance competed with adhesion inside one shared pool.
  * The tissue compartment is the delivered model verbatim (same ode_system
    code path); only k_mcc is set to zero. Any difference in tissue dynamics
    is therefore attributable to the lumen filter, not to refactoring.
  * The lumen has no immune states: airway antimicrobial defense is lumped
    into k_cd_death (minimal structure).
  * Inoculum fate partition is computed EXACTLY via 3 cumulative flux states
    (C_cum, D_cum, I_cum, appended after the 22 biological states): mucociliary
    clearance, luminal death, tissue invasion. The conservation identity
    Cl_L(0) = Cl_L + Cd_L + Cs_L + C_cum + D_cum + I_cum holds at all times,
    so fate fractions sum to <= 1 by construction. (Integrating the fluxes by
    trapezoid on a coarse t_eval grid overestimates the fast clearance phase
    -- the reason these states exist.)
"""
import numpy as np
from scipy.integrate import solve_ivp

import fungal_sinusitis_ode_model as fsm

# new parameters (appended to a copy of the base parameter dict)
DEFAULT_PARAMS_2C = fsm.DEFAULT_PARAMS.copy()
DEFAULT_PARAMS_2C['k_inv'] = 0.1    # /h, epithelial invasion (est)
DEFAULT_PARAMS_2C['Fe_L'] = 0.05    # AU, airway-surface-liquid free iron (est)

STATE_NAMES_2C = ['Cl_L', 'Cd_L', 'Cs_L'] + fsm.STATE_NAMES  # 22 bio states
N_LUMEN = 3
CUM_NAMES = ['C_cum', 'D_cum', 'I_cum']        # cumulative inoculum fates
STATE_NAMES_FULL = STATE_NAMES_2C + CUM_NAMES  # 25 solver states

DEFAULT_IC_2C = {'Cl_L': 100.0, 'Cd_L': 0.0, 'Cs_L': 0.0}
for _n, _v in fsm.DEFAULT_IC.items():
    DEFAULT_IC_2C[_n] = _v
DEFAULT_IC_2C['Cl'] = 0.0  # inoculum starts in the lumen, tissue sterile
for _c in CUM_NAMES:
    DEFAULT_IC_2C[_c] = 0.0


def ode_system_2c(t, y, params, lumped):
    """25-state RHS: 3 lumen + 19 tissue (delivered model) + 3 cumulative fates."""
    Cl_L, Cd_L, Cs_L = y[0], y[1], y[2]
    p = params

    # --- lumen (iron-limited germination; no immune cells) ---
    gFe_L = p['Fe_L'] / (p['K_Fe_germ'] + p['Fe_L'])
    dCl_L = -p['k_adh'] * Cl_L - p['k_mcc'] * Cl_L
    dCd_L = (p['k_adh'] * Cl_L
             - p['k_germ'] * Cd_L * gFe_L
             - p['k_cd_death'] * Cd_L)
    dCs_L = (p['k_germ'] * Cd_L * gFe_L
             - p['k_inv'] * Cs_L
             - p['k_cd_death'] * Cs_L)

    # --- tissue: delivered 19-state model with k_mcc = 0 (luminal clearance) ---
    p_t = p.copy()
    p_t['k_mcc'] = 0.0
    n_t = len(fsm.STATE_NAMES)
    d_tissue = fsm.ode_system(t, y[N_LUMEN:N_LUMEN + n_t], p_t, lumped)
    d_tissue[fsm.STATE_NAMES.index('Cs')] += p['k_inv'] * Cs_L  # invasion flux

    # cumulative inoculum fates (exact partition; see module docstring)
    dC_cum = p['k_mcc'] * Cl_L                # cleared by mucociliary transport
    dD_cum = p['k_cd_death'] * (Cd_L + Cs_L)  # died in the lumen
    dI_cum = p['k_inv'] * Cs_L                # invaded the tissue
    return np.concatenate([[dCl_L, dCd_L, dCs_L], d_tissue,
                           [dC_cum, dD_cum, dI_cum]])


def solve_model_2c(params=None, lumped=None, ic=None, t_span=(0.0, 168.0),
                   t_eval=None, neutropenia=None, params_override=None,
                   mucociliary=None):
    """Solve the two-compartment model (interface mirrors fsm.solve_model).

    mucociliary : dict or None, e.g. {'k_mcc_mult': 0.1} for dysfunction
        (CRS / primary ciliary dyskinesia analog).
    """
    params = (DEFAULT_PARAMS_2C.copy() if params is None else params.copy())
    lumped = ({'alpha': 1.0, 'beta': 1.0, 'gamma': 1.0} if lumped is None
              else lumped.copy())
    ic = (DEFAULT_IC_2C.copy() if ic is None else ic.copy())
    if t_eval is None:
        t_eval = np.linspace(t_span[0], t_span[1], 841)
    if params_override:
        params.update(params_override)
    if mucociliary is not None:
        params['k_mcc'] = params['k_mcc'] * mucociliary.get('k_mcc_mult', 1.0)
    if neutropenia is not None:
        params['N_base'] = neutropenia.get('N_base', 0.05)
        params['k_N_rec'] = params['k_N_rec'] * neutropenia.get('k_N_rec_mult', 0.1)

    y0 = np.array([ic[name] for name in STATE_NAMES_FULL])
    return solve_ivp(
        fun=lambda t, y: ode_system_2c(t, y, params, lumped),
        t_span=t_span, y0=y0, t_eval=t_eval,
        method='LSODA', rtol=1e-8, atol=1e-10,
    )


def outcome_metrics_2c(result):
    """Tissue-side outcomes + inoculum fate partition.

    Fates come from the exact cumulative flux states (no rate constants, no
    quadrature), so the partition sums to <= 1 by construction, is independent
    of the t_eval grid, and uses the parameters actually solved with. The
    denominator is the actual luminal inoculum Cl_L(t=0), so non-default
    inocula are handled correctly.
    """
    t = result.t
    H_T = result.y[N_LUMEN + fsm.STATE_NAMES.index('H')]
    i0 = len(STATE_NAMES_2C)
    Cl0 = max(result.y[0, 0], 1e-9)
    return {
        'H_end': H_T[-1],
        'H_auc': np.trapezoid(H_T, t),
        'H_peak': H_T.max(),
        'f_cleared': result.y[i0][-1] / Cl0,      # C_cum: cleared by transport
        'f_died': result.y[i0 + 1][-1] / Cl0,     # D_cum: died in lumen
        'f_invaded': result.y[i0 + 2][-1] / Cl0,  # I_cum: invaded tissue
    }
