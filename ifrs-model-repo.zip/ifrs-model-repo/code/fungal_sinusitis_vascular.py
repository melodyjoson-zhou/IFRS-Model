"""
Vascular -- thrombosis -- necrosis module for the IFRS two-compartment model.

Motivation: angioinvasion (hyphal invasion of submucosal vessels with
thrombosis and ischemic necrosis) is the histological hallmark of IFRS/ROCM
and the mechanistic basis of surgical debridement, but the delivered bone
module represents it only as a barrier-independent seeding flux k_ang_i*H.
This module makes the vascular chain explicit with 3 tissue-level states
(appended to the 25-state two-compartment model -> 28 states):

  E    infected endothelium fraction [0,1]:
       dE/dt = k_endo * gFe_H * H^2/(K_endo^2+H^2) * (1-E) - k_E_loss * E
       endothelial invasion saturating in tissue hyphae H and gated by the
       SAME iron-availability function gFe_H as hyphal extension -- the
       CotH3-GRP78 invasion axis is upregulated by the diabetic/iron-loaded
       milieu (GRP78 is the endothelial receptor; hyperglycemia glycosylates
       transferrin/ferritin and ketosis + free iron upregulate GRP78 -- Liu
       2010 JCI; Gebremariam 2013 JCI; Baldin & Ibrahim 2017), so an
       iron-replete host invades vessels at a LOWER burden.

  Th   thrombosed-vessel fraction [0,1]:
       dTh/dt = k_thromb * E * (1-Th) - k_fibrin * Th
       thrombosis driven by infected endothelium (endothelial damage ->
       tissue-factor/platelet activation -- Ibrahim 2012 CID; Ghuman &
       Voelz 2017), opposed by endogenous fibrinolysis.

  Nec  necrotic (infarcted) tissue fraction [0,1]:
       dNec/dt = k_nec * Th * (1-Nec) - k_nec_rep * Nec
       ischemic infarction follows vessel occlusion over hours ("rapid
       progression" -- Lynch 2023); repair is slow and anchored to the
       delivered mucosal-repair timing (k_repair = 0.004/h, Xu 1999/2008).

Feedbacks (the mechanistic core of the extension):
  * DRUG GATING: antifungal efficacy is scaled by the perfused fraction --
    the effective growth reduction is eff*(1-Nec), because drug does not
    reach avascular (necrotic) tissue. This mechanizes the disclosed
    model-clinical discrepancy (uniform drug action overestimates
    monotherapy) and gives debridement (which REMOVES necrotic tissue) an
    explicit marginal value.
  * IMMUNE GATING: neutrophil killing and phagocytosis rates are scaled by
    (1-Nec) -- effectors function poorly in dead tissue.
  * IRON RELEASE: necrotic tissue releases iron (dFe/dt += k_Fe_nec*Nec) --
    the vicious cycle of necrosis fueling fungal growth.
  * ANGIO SEEDING AMPLIFICATION: the bone-module angioinvasive seeding term
    becomes k_ang_i * H * (1 + a_thromb * Th) -- at Th = 0 the delivered
    behavior is recovered exactly (design anchors preserved).

Debridement redefinition: surgical debridement removes devitalized tissue --
the step reduction now also applies to Nec (Nec -> (1-deb_frac)*Nec).

New parameters (9, all estimated/C-class; qualitative anchors documented):
  k_endo  = 0.1  /h      endothelial invasion rate (~10 h timescale;
                         Hill n=2 in H at K_endo, mirroring the bone
                         destruction threshold; GRP78/CotH axis qualitative)
  K_endo  = 5.0  AU      Hill (n=2) threshold of endothelial invasion in H
                         (mirrors K_Hb: invasion needs escape-level burden)
  k_E_loss = 0.1 /h      infected-endothelium loss/turnover (~10 h)
  k_thromb = 0.1 /h      thrombosis on infected endothelium (hours)
  k_fibrin = 0.1 /h      endogenous fibrinolysis (t1/2 ~ 7 h)
  k_nec   = 0.05 /h      infarction after occlusion (~14 h; ischemic
                         necrosis evolves over 6-24 h)
  k_nec_rep = 0.004 /h   slow necrosis repair (anchored to k_repair)
  a_thromb = 4.0 -       thrombosis amplification of angio seeding
                         (thrombosed vessels seed 5x at full occlusion)
  k_Fe_nec = 0.05 AU/h  iron release from necrotic tissue (est; small by
                         calibration -- Nec_peak sensitivity -0.005 and the
                         host hierarchy 0.030 < 0.037 << 14.61 is preserved;
                         an earlier pre-rebalanced configuration at this
                         value broke the hierarchy, motivating the small rate)

Unit tests verify: (i) with k_nec = 0 (Nec identically 0) the 28-state
tissue trajectory matches the 25-state two-compartment model exactly
(plumbing check); (ii) E, Th, Nec remain in [0,1]; (iii) the phenotype
hierarchy and bone design anchors are preserved.
"""
import numpy as np
from scipy.integrate import solve_ivp

import fungal_sinusitis_ode_model as fsm
import fungal_sinusitis_2comp as f2c
import fungal_sinusitis_bone as fb

# --- parameters ----------------------------------------------------------------
DEFAULT_PARAMS_VASC = f2c.DEFAULT_PARAMS_2C.copy()
DEFAULT_PARAMS_VASC.update({
    'k_endo': 0.1,     # /h/AU, endothelial invasion (est; GRP78/CotH axis)
    'K_endo': 5.0,     # AU, half-saturation in H (est; mirrors K_Hb scale)
    'k_E_loss': 0.1,   # /h, infected endothelium turnover (est)
    'k_thromb': 0.1,   # /h, thrombosis on infected endothelium (est)
    'k_fibrin': 0.1,   # /h, endogenous fibrinolysis (t1/2 ~ 7 h, est)
    'k_nec': 0.05,     # /h, ischemic infarction after occlusion (est)
    'k_nec_rep': 0.004,# /h, slow repair (anchored to k_repair, Xu 1999/2008)
    'a_thromb': 4.0,   # -, angio-seeding amplification at full occlusion (est)
    'k_Fe_nec': 0.05,  # AU/h, iron release from necrotic tissue (est)
})
DEFAULT_PARAMS_VASC.update({k: v for k, v in fb.DEFAULT_PARAMS_BONE.items()
                            if k not in DEFAULT_PARAMS_VASC})

VASC_NAMES = ['E', 'Th', 'Nec']
STATE_NAMES_VASC = f2c.STATE_NAMES_FULL + VASC_NAMES            # 28 states
BONE_NAMES = fb.STATE_NAMES_BONE[len(f2c.STATE_NAMES_FULL):]    # 6 bone states
STATE_NAMES_VB = STATE_NAMES_VASC + BONE_NAMES                  # 34 states

DEFAULT_IC_VASC = f2c.DEFAULT_IC_2C.copy()
for _n in VASC_NAMES:
    DEFAULT_IC_VASC[_n] = 0.0
DEFAULT_IC_VB = dict(DEFAULT_IC_VASC)
DEFAULT_IC_VB.update({'B_ORB': 1.0, 'D_ORB': 0.0, 'B_ITF': 1.0, 'D_ITF': 0.0,
                      'B_CS': 1.0, 'D_CS': 0.0})

_N25 = len(f2c.STATE_NAMES_FULL)
_I_H = f2c.N_LUMEN + fsm.STATE_NAMES.index('H')     # tissue hyphae index
_I_Fe = f2c.N_LUMEN + fsm.STATE_NAMES.index('Fe')   # free iron index
_I_E, _I_Th, _I_Nec = _N25, _N25 + 1, _N25 + 2
_ROUTES = [('k_bone_ORB', 'k_angio_ORB'), ('k_bone_ITF', 'k_angio_ITF'),
           ('k_bone_CS', 'k_angio_CS')]
DEBRIDED_STATES = fb.DEBRIDED_STATES + ['Nec']      # surgery also removes
                                                    # devitalized tissue


def _gate_params(p, Nec, af_eff=0.0):
    """Necrosis-gated parameter set: immune effectors and drug action scale
    with the perfused fraction (1 - Nec)."""
    perf = max(1.0 - Nec, 0.0)
    pg = p.copy()
    for k in ('k_phag', 'k_Nkill', 'k_Nkill_s'):
        pg[k] = p[k] * perf
    if af_eff > 0:
        pg['mu_H'] = p['mu_H'] * (1.0 - af_eff * perf)
    return pg


def ode_system_vasc(t, y, params, lumped, af_eff=0.0):
    """28-state RHS: 25-state two-compartment model + E/Th/Nec vascular chain.

    af_eff > 0 activates the necrosis-gated antifungal action (call within a
    segment whose start already passed t_af)."""
    p = params
    Nec = min(max(y[_I_Nec], 0.0), 1.0)
    y25 = y[:_N25]
    H = y[_I_H]
    Fe = y[_I_Fe]

    pg = _gate_params(p, Nec, af_eff=af_eff)
    d25 = f2c.ode_system_2c(t, y25, pg, lumped)
    d25 = d25.copy()
    d25[_I_Fe] += p['k_Fe_nec'] * Nec          # necrosis releases iron

    gFe_H = Fe / (p['K_Fe_H'] + Fe)            # same iron gate as hyphae
    gH2 = H**2 / (p['K_endo']**2 + H**2)   # Hill n=2: vessel invasion needs
                                            # substantial burden (mirrors K_Hb)
    dE = (p['k_endo'] * gFe_H * gH2 * (1.0 - y[_I_E])
          - p['k_E_loss'] * y[_I_E])
    dTh = (p['k_thromb'] * y[_I_E] * (1.0 - y[_I_Th])
           - p['k_fibrin'] * y[_I_Th])
    dNec = (p['k_nec'] * y[_I_Th] * (1.0 - Nec)
            - p['k_nec_rep'] * Nec)
    return np.concatenate([d25, [dE, dTh, dNec]])


def ode_system_vasc_bone(t, y, params, lumped, af_eff=0.0):
    """34-state RHS: 28-state vascular model + 6 bone/deep-space states.

    dD_i/dt = (k_inv*(1-B_i) + k_ang_i*(1 + a_thromb*Th))*H + (mu_H_eff -
    k_Ddeath)*D_i: the direct route is barrier-gated as delivered; the
    angioinvasive route is amplified by thrombosis (infected/occluded vessels
    carry fungus) and recovers the delivered flux exactly at Th = 0."""
    p = params
    d28 = ode_system_vasc(t, y[:len(STATE_NAMES_VASC)], p, lumped, af_eff=af_eff)
    H = y[_I_H]
    Th = min(max(y[_I_Th], 0.0), 1.0)
    Nec = min(max(y[_I_Nec], 0.0), 1.0)
    mu_eff = p['mu_H'] * (1.0 - af_eff * max(1.0 - Nec, 0.0))
    mu_net = mu_eff - p['k_Ddeath']
    d_bone = []
    for j, (kb, ka) in enumerate(_ROUTES):
        B = y[len(STATE_NAMES_VASC) + 2 * j]
        D = y[len(STATE_NAMES_VASC) + 2 * j + 1]
        gH = H**2 / (p['K_Hb']**2 + H**2)
        d_bone += [-p[kb] * gH * B,
                   (p['k_inv'] * (1.0 - B)
                    + p[ka] * (1.0 + p['a_thromb'] * Th)) * H + mu_net * D]
    return np.concatenate([d28, d_bone])


def _prepare(params, lumped, neutropenia, mucociliary, params_override):
    p = (DEFAULT_PARAMS_VASC.copy() if params is None else params.copy())
    L = ({'alpha': 1.0, 'beta': 1.0, 'gamma': 1.0} if lumped is None
         else lumped.copy())
    if params_override:
        p.update(params_override)
    if mucociliary is not None:
        p['k_mcc'] = p['k_mcc'] * mucociliary.get('k_mcc_mult', 1.0)
    if neutropenia is not None:
        p['N_base'] = neutropenia.get('N_base', 0.05)
        p['k_N_rec'] = p['k_N_rec'] * neutropenia.get('k_N_rec_mult', 0.1)
    return p, L


def solve_model_vasc(params=None, lumped=None, ic=None, t_span=(0.0, 168.0),
                     t_eval=None, neutropenia=None, params_override=None,
                     mucociliary=None, af_eff=0.0):
    """Solve the 28-state vascular model (interface mirrors solve_model_2c)."""
    p, L = _prepare(params, lumped, neutropenia, mucociliary, params_override)
    ic = (DEFAULT_IC_VASC.copy() if ic is None else ic.copy())
    if t_eval is None:
        t_eval = np.linspace(t_span[0], t_span[1], 841)
    y0 = np.array([ic[nm] for nm in STATE_NAMES_VASC])
    return solve_ivp(
        fun=lambda t, y: ode_system_vasc(t, y, p, L, af_eff=af_eff),
        t_span=t_span, y0=y0, t_eval=t_eval, method='LSODA',
        rtol=1e-8, atol=1e-10)


def solve_model_vasc_bone(params=None, lumped=None, ic=None,
                          t_span=(0.0, 504.0), t_eval=None, neutropenia=None,
                          params_override=None, mucociliary=None, af_eff=0.0):
    """Solve the 34-state vascular+bone model."""
    p, L = _prepare(params, lumped, neutropenia, mucociliary, params_override)
    ic = (DEFAULT_IC_VB.copy() if ic is None else ic.copy())
    if t_eval is None:
        t_eval = np.linspace(t_span[0], t_span[1], 1261)
    y0 = np.array([ic[nm] for nm in STATE_NAMES_VB])
    return solve_ivp(
        fun=lambda t, y: ode_system_vasc_bone(t, y, p, L, af_eff=af_eff),
        t_span=t_span, y0=y0, t_eval=t_eval, method='LSODA',
        rtol=1e-8, atol=1e-10)


def simulate_vasc_intervention(t_af=None, eff=0.0, t_deb=None, deb_frac=0.9,
                               t_rec=None, neutropenic=False, lumped=None,
                               t_span=(0.0, 504.0), t_eval=None,
                               params_override=None, mucociliary=None,
                               bone=True):
    """Piecewise 34-state (bone=True) or 28-state (bone=False) simulation.

    Antifungal (eff from t_af) is NECROSIS-GATED inside the RHS: the effective
    growth reduction is eff*(1-Nec(t)). Debridement at t_deb step-reduces the
    fungal chain AND the necrotic fraction by deb_frac. Neutropenia lifted
    from t_rec. Returns t (N,), Y (N, n_states) in STATE_NAMES_VB / VASC order.
    """
    L = lumped or {'alpha': 1.0, 'beta': 1.0, 'gamma': 1.0}
    solve_fn = solve_model_vasc_bone if bone else solve_model_vasc
    names = STATE_NAMES_VB if bone else STATE_NAMES_VASC
    onsets = [t for t in ((t_af if eff > 0 else None), t_deb, t_rec) if t is not None]
    events = sorted({0.0, t_span[1]} | {max(0.0, t) for t in onsets})
    if t_eval is None:
        t_eval = np.linspace(t_span[0], t_span[1], 1261)
    y0, ts, ys = None, [], []
    for t0, t1 in zip(events[:-1], events[1:]):
        if t1 - t0 < 1e-9:
            continue
        af_seg = eff if (eff > 0 and t_af is not None
                         and t0 >= max(t_af, 0.0) - 1e-9) else 0.0
        kw = dict(params=None, lumped=L, t_span=(t0, t1),
                  t_eval=t_eval[(t_eval >= t0 - 1e-9) & (t_eval <= t1 + 1e-9)],
                  params_override=params_override, mucociliary=mucociliary,
                  af_eff=af_seg)
        if y0 is None:
            ic = (DEFAULT_IC_VB if bone else DEFAULT_IC_VASC).copy()
            if t_deb is not None and t0 >= max(t_deb, 0.0) - 1e-9:
                for nm in DEBRIDED_STATES:
                    ic[nm] *= (1.0 - deb_frac)
            kw['ic'] = ic
        else:
            if t_deb is not None and abs(t0 - max(t_deb, 0.0)) < 1e-9:
                y0 = y0.copy()
                for nm in DEBRIDED_STATES:
                    y0[nm] *= (1.0 - deb_frac)
            kw['ic'] = y0
        if neutropenic and (t_rec is None or t0 < t_rec - 1e-9):
            kw['neutropenia'] = {'N_base': 0.05, 'k_N_rec_mult': 0.1}
        r = solve_fn(**kw)
        y0 = {nm: r.y[j][-1] for j, nm in enumerate(names)}
        ts.append(r.t); ys.append(r.y.T)
    t_c = np.concatenate(ts); Y_c = np.concatenate(ys, axis=0)
    keep = np.concatenate([[True], np.diff(t_c) > 1e-9])
    return t_c[keep], Y_c[keep]


def outcome_metrics_vasc(result, bone=True):
    """Vascular-chain outcomes: end/peak values and crossing times for E, Th,
    Nec (thresholds 0.5 / 0.5 / 0.05), plus bone/deep metrics per route
    (breach = B_i crosses 0.5, establishment = D_i crosses 1 AU; NaN = never
    within the horizon) computed on the 34-state layout (bone states start at
    index 28, NOT the 31-state module's 25)."""
    t = result.t
    Y = result.y
    out = {}
    for nm, thr in (('E', 0.5), ('Th', 0.5), ('Nec', 0.05)):
        ix = STATE_NAMES_VASC.index(nm)
        v = Y[ix]
        out[f'{nm}_end'] = v[-1]
        out[f'{nm}_peak'] = v.max()
        cross = np.nan if v.max() < thr else t[np.argmax(v >= thr)]
        out[f't_{nm}'] = cross
    if bone:
        out['H_end'] = Y[_I_H][-1]
        out['H_auc'] = np.trapezoid(Y[_I_H], t)
        n28 = len(STATE_NAMES_VASC)
        for j, (kb, ka) in enumerate(_ROUTES):
            route = ('ORB', 'ITF', 'CS')[j]
            B = Y[n28 + 2 * j]
            D = Y[n28 + 2 * j + 1]
            ib = np.argmax(B < 0.5) if (B < 0.5).any() else -1
            idd = np.argmax(D > 1.0) if (D > 1.0).any() else -1
            out[f't_breach_{route}'] = t[ib] if ib >= 0 else np.nan
            out[f't_deep_{route}'] = t[idd] if idd >= 0 else np.nan
            out[f'B_end_{route}'] = B[-1]
            out[f'D_end_{route}'] = D[-1]
    return out
