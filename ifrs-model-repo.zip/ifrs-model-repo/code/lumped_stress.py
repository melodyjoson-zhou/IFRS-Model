"""lumped_stress.py — Non-uniformity stress test for the aggregate modifiers
alpha/beta of the IFRS core model (round 6).

The delivered core model (fungal_sinusitis_ode_model.py) scales multiple
mechanisms with single scalars (uniform-effect assumption, manuscript S2.4):

    alpha: phagocytosis (k_phag), neutrophil killing (k_Nkill, k_Nkill_s),
           immune suppression of extension (E_immune), iron sequestration
           (k_seq), chemokine-driven recruitment (k_N_rec)
    beta : gliotoxin production (k_gtx_prod), siderophore production
           (k_sid_prod) and its reclaim effect, conidial masking (s_mask)
    gamma: IL-10 production (single mechanism — not split)

This module splits alpha and beta into per-mechanism scalars so the
uniformity assumption can be broken deliberately:

    alpha -> a_phag, a_kill, a_reg
    beta  -> b_gtx, b_sid, b_shield

lumped_gen dict keys: a_phag, a_kill, a_reg, b_gtx, b_sid, b_shield, gamma.
With every value 1.0 the RHS reproduces the delivered core model pointwise
(regression anchor); with every value set to the same c it reproduces
lumped = {'alpha': c, 'beta': c, 'gamma': c}.
"""
import numpy as np
from scipy.integrate import solve_ivp

import fungal_sinusitis_ode_model as fsm

_N19 = len(fsm.STATE_NAMES)


def default_lumped_gen():
    return {'a_phag': 1.0, 'a_kill': 1.0, 'a_reg': 1.0,
            'b_gtx': 1.0, 'b_sid': 1.0, 'b_shield': 1.0, 'gamma': 1.0}


def ode_system_gen(t, y, params, lumped_gen):
    """19-dim IFRS RHS with per-mechanism modifier scalars."""
    (Cl, Cd, Cs, H, Hd, Fe, BG, D, NF, Cy,
     Ch, N, Na, M, Ma, Il10, Gtx, Sid, Td) = y
    p = params
    a_phag = lumped_gen['a_phag']
    a_kill = lumped_gen['a_kill']
    a_reg = lumped_gen['a_reg']
    b_gtx = lumped_gen['b_gtx']
    b_sid = lumped_gen['b_sid']
    b_shield = lumped_gen['b_shield']
    g = lumped_gen['gamma']

    # iron availability functions
    gFe_germ = Fe / (p['K_Fe_germ'] + Fe)
    gFe_H = Fe / (p['K_Fe_H'] + Fe)

    # siderophores reclaim host-sequestered iron (b_sid-scaled)
    reclaim = 1.0 / (1.0 + b_sid * p['s_sid'] * Sid / p['K_sid'])

    # immune suppression of hyphal extension (a_kill-scaled)
    E_immune = 1.0 / (1.0 + (a_kill * Na / p['K_E']) ** p['h_E'])

    # gliotoxin suppression of leucocyte activation
    G_sup = 1.0 / (1.0 + (Gtx / p['K_gtx']) ** p['n_gtx'])

    # IL-10 repression of NF-kB (gamma-scaled feedback)
    IL10_rep = 1.0 / (1.0 + (g * Il10 / p['K_il10']) ** p['n_il10'])

    # conidial beta-glucan masking (b_shield-scaled)
    mask = 1.0 - b_shield * p['s_mask'] * (Cd / (p['K_phag'] + Cd))
    mask = max(mask, 0.0)

    # --- fungal module ---
    dCl = -p['k_adh'] * Cl - p['k_mcc'] * Cl
    dCd = (p['k_adh'] * Cl
           - a_phag * p['k_phag'] * Ma * Cd / (p['K_phag'] + Cd)
           - p['k_germ'] * Cd * gFe_germ
           - p['k_cd_death'] * Cd)
    dCs = (p['k_germ'] * Cd * gFe_germ
           - p['k_sw2H'] * Cs * gFe_H
           - a_phag * p['k_phag'] * Ma * Cs / (p['K_phag'] + Cs)
           - a_kill * p['k_Nkill_s'] * Na * Cs / (p['K_kills'] + Cs))
    dH = (p['k_sw2H'] * Cs * gFe_H
          + p['mu_H'] * H * gFe_H * (1.0 - H / p['K_H']) * E_immune
          - a_kill * p['k_Nkill'] * Na * H / (p['K_kill'] + H)
          - p['k_H_death'] * H)
    dHd = (a_kill * p['k_Nkill'] * Na * H / (p['K_kill'] + H)
           + a_kill * p['k_Nkill_s'] * Na * Cs / (p['K_kills'] + Cs)
           - p['k_Hd_clear'] * Hd)
    dFe = (p['k_Fe_in']
           - a_reg * p['k_seq'] * Fe * (1.0 + p['s_seq'] * N) * reclaim
           - p['k_up'] * H * Fe / (p['K_Fe_H'] + Fe))
    dBG = (p['k_BG_H'] * H + p['k_BG_s'] * Cs * mask
           - p['k_BG_clear'] * BG)

    # --- sensing / signaling ---
    phag_flux = a_phag * p['k_phag'] * Ma * Cd / (p['K_phag'] + Cd)
    dD = p['k_D'] * BG * (1.0 - D) - p['k_Doff'] * D + p['k_D_phag'] * phag_flux * G_sup
    dNF = p['k_NF'] * D * (1.0 - NF) * IL10_rep - p['k_NF_off'] * NF
    dCy = p['k_Cy'] * NF - p['k_Cy_clear'] * Cy
    dCh = p['k_Ch'] * NF - p['k_Ch_clear'] * Ch

    # --- effectors ---
    dN = (p['k_N_base'] * (p['N_base'] - N)
          + a_reg * p['k_N_rec'] * Ch * (1.0 - N / p['N_max'])
          - p['k_N_apop'] * N)
    dNa = p['k_Na_act'] * Cy * (N - Na) * G_sup - p['k_Na_deact'] * Na
    dM = (p['k_M_base'] * (p['M_base'] - M)
          + p['k_M_rec'] * Cy * (1.0 - M / p['M_max'])
          - p['k_M_off'] * M)
    dMa = p['k_Ma_act'] * D * (M - Ma) * G_sup - p['k_Ma_deact'] * Ma
    dIl10 = g * p['k_il10_prod'] * (Na + Ma) - p['k_il10_clear'] * Il10

    # --- fungal antagonism effectors ---
    dGtx = b_gtx * p['k_gtx_prod'] * H - p['k_gtx_clear'] * Gtx
    dSid = b_sid * p['k_sid_prod'] * H - p['k_sid_clear'] * Sid

    # --- outcome ---
    dTd = p['k_td'] * H * (1.0 - Td / p['Td_max']) - p['k_repair'] * Td

    return np.array([dCl, dCd, dCs, dH, dHd, dFe, dBG, dD, dNF, dCy,
                     dCh, dN, dNa, dM, dMa, dIl10, dGtx, dSid, dTd])


def solve_model_gen(lumped_gen=None, ic=None, t_span=(0.0, 168.0),
                    t_eval=None, neutropenia=None, params_override=None,
                    params=None):
    """Mirror of fsm.solve_model using the per-mechanism RHS."""
    params = (fsm.DEFAULT_PARAMS.copy() if params is None else params.copy())
    lumped_gen = default_lumped_gen() if lumped_gen is None else lumped_gen.copy()
    ic = fsm.DEFAULT_IC.copy() if ic is None else ic.copy()
    if t_eval is None:
        t_eval = np.linspace(t_span[0], t_span[1], 841)
    if params_override:
        params.update(params_override)
    if neutropenia is not None:
        params['N_base'] = neutropenia.get('N_base', 0.05)
        params['k_N_rec'] = params['k_N_rec'] * neutropenia.get('k_N_rec_mult', 0.1)
    y0 = np.array([ic[name] for name in fsm.STATE_NAMES])
    return solve_ivp(
        fun=lambda t, y: ode_system_gen(t, y, params, lumped_gen),
        t_span=t_span, y0=y0, t_eval=t_eval,
        method='LSODA', rtol=1e-8, atol=1e-10,
    )


def skew_lumped_gen(modifier, base, f):
    """Per-mechanism scalars under a pairwise-reverse skew of magnitude f.

    beta : b_gtx = base*f, b_sid = base/f, b_shield = base
    alpha: a_phag = base*f, a_kill = base/f, a_reg = base
    Total modifier 'mass' (geometric mean of the skewed pair) is unchanged;
    only its distribution across mechanisms shifts.
    """
    L = default_lumped_gen()
    if modifier == 'beta':
        L['b_gtx'], L['b_sid'], L['b_shield'] = base * f, base / f, base
    elif modifier == 'alpha':
        L['a_phag'], L['a_kill'], L['a_reg'] = base * f, base / f, base
    else:
        raise ValueError(modifier)
    return L


def outcome_metrics_gen(result):
    t = result.t
    H = result.y[fsm.STATE_NAMES.index('H')]
    Td = result.y[fsm.STATE_NAMES.index('Td')]
    return {'H_end': H[-1], 'H_auc': np.trapezoid(H, t),
            'H_peak': H.max(), 'Td_end': Td[-1]}


def simulate_treatment_gen(lumped_gen, t_start, eff, neutropenic=True,
                           t_end=168.0):
    """Piecewise antifungal simulation (mu_H x (1-eff) from t_start) on the
    per-mechanism RHS; mirrors the delivered intervention machinery."""
    onsets = [t_start] if (eff > 0 and t_start is not None) else []
    events = sorted({0.0, t_end} | {max(0.0, t) for t in onsets})
    y0, ts, ys = None, [], []
    for t0, t1 in zip(events[:-1], events[1:]):
        if t1 - t0 < 1e-9:
            continue
        p = fsm.DEFAULT_PARAMS.copy()
        if eff > 0 and t_start is not None and t0 >= max(t_start, 0.0) - 1e-9:
            p['mu_H'] *= (1.0 - eff)
        kw = dict(params=p, lumped_gen=lumped_gen, t_span=(t0, t1),
                  t_eval=np.linspace(t0, t1, max(2, int(round((t1 - t0) / 0.2)) + 1)))
        if y0 is not None:
            kw['ic'] = y0
        if neutropenic:
            kw['neutropenia'] = {'N_base': 0.05, 'k_N_rec_mult': 0.1}
        r = solve_model_gen(**kw)
        y0 = {nm: r.y[j][-1] for j, nm in enumerate(fsm.STATE_NAMES)}
        ts.append(r.t); ys.append(r.y.T)
    t_c = np.concatenate(ts)
    Y_c = np.concatenate(ys, axis=0)
    keep = np.concatenate([[True], np.diff(t_c) > 1e-9])
    return t_c[keep], Y_c[keep]


if __name__ == '__main__':
    # Regression anchors: uniform scalars must reproduce the delivered core.
    t_eval = np.linspace(0.0, 168.0, 841)
    for c in (1.0, 2.0):
        r_core = fsm.solve_model(lumped={'alpha': c, 'beta': c, 'gamma': c}, t_eval=t_eval)
        L = default_lumped_gen()
        if c != 1.0:
            L = {k: c for k in L}
        r_gen = solve_model_gen(lumped_gen=L, t_eval=t_eval)
        diff = float(np.max(np.abs(r_core.y - r_gen.y)))
        print(f"uniform c={c}: max|core - generalized| = {diff:.2e}")
